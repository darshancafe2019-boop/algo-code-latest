"""
BTC Trading Bot - Production-Grade Live Web Dashboard
=====================================================
Run this application to launch the full-featured, professional trading dashboard UI.

Access via browser: http://127.0.0.1:5050
"""

import sys
import os
import sqlite3
import json
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
import io
import csv

from flask import Flask, jsonify, render_template, request, Response, send_file

# Add project root to sys.path
project_root = Path(__file__).resolve().parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from src import config
from src import db
from src import audit
from src.process_manager import bot_manager
from src.data_fetcher import DataFetcher
from src.indicators import generate_indicators, calculate_volume_profile
logger = logging.getLogger("DashboardAPI")

try:
    from src.backtester import run_backtest
except ImportError as e:
    logger.warning(f"Backtester module import deferred: {e}")
    def run_backtest(*args, **kwargs):
        raise RuntimeError("Backtrader library is not installed in current environment. Please install backtrader or run within .venv.")

from src.telegram_alert import TelegramAlert

# Initialize Flask App
app = Flask(__name__, template_folder="templates", static_folder="static")



# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
def get_db_conn():
    """Create SQLite connection with Row factory."""
    db.init_db()
    audit.init_audit_db()
    conn = sqlite3.connect(str(config.DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def safe_query(sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    """Execute SQL query safely and return list of dicts."""
    conn = None
    try:
        conn = get_db_conn()
        cur = conn.cursor()
        cur.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()]
        return rows
    except Exception as e:
        logger.error(f"Database query error [{sql}]: {e}")
        return []
    finally:
        if conn:
            conn.close()


def safe_query_one(sql: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
    """Execute SQL query returning single dict or None."""
    rows = safe_query(sql, params)
    return rows[0] if rows else None


# ============================================================================
# MAIN ROUTE
# ============================================================================
@app.route("/")
def index():
    """Render main dashboard single-page web app."""
    return render_template("index.html")


# ============================================================================
# SECTION 1: TRADING & CHARTING ENDPOINTS
# ============================================================================
@app.route("/api/ticker")
def api_ticker():
    """Fetch live ticker data (price, 24h change %, high/low, volume)."""
    try:
        fetcher = DataFetcher(use_testnet=False)
        # Fetch 24h ticker from Binance via CCXT
        ticker = fetcher.exchange.fetch_ticker(config.SYMBOL)
        
        # Calculate exchange latency
        start_t = datetime.now()
        fetcher.exchange.fetch_time()
        latency_ms = int((datetime.now() - start_t).total_seconds() * 1000)

        payload = {
            "symbol": config.SYMBOL,
            "last": float(ticker.get("last") or 0.0),
            "high": float(ticker.get("high") or 0.0),
            "low": float(ticker.get("low") or 0.0),
            "volume": float(ticker.get("baseVolume") or 0.0),
            "change_pct": float(ticker.get("percentage") or 0.0),
            "change_val": float(ticker.get("change") or 0.0),
            "bid": float(ticker.get("bid") or 0.0),
            "ask": float(ticker.get("ask") or 0.0),
            "latency_ms": latency_ms,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        return jsonify({"status": "success", "data": payload})
    except Exception as e:
        logger.error(f"Ticker endpoint error: {e}")
        # Return DB cached candle or fallback
        last_candle = safe_query_one("SELECT close FROM candles_cache ORDER BY timestamp DESC LIMIT 1")
        last_price = last_candle["close"] if last_candle else 65000.0
        return jsonify({
            "status": "warning",
            "message": f"Exchange API issue: {str(e)}. Displaying fallback price.",
            "data": {
                "symbol": config.SYMBOL,
                "last": float(last_price),
                "high": float(last_price * 1.02),
                "low": float(last_price * 0.98),
                "volume": 1250.50,
                "change_pct": 0.55,
                "change_val": 350.0,
                "bid": float(last_price * 0.999),
                "ask": float(last_price * 1.001),
                "latency_ms": 999,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        })


@app.route("/api/candles")
def api_candles():
    """Fetch OHLCV candles with EMA (9, 20, 50, 200), MACD, RSI, and Volume Profile."""
    timeframe = request.args.get("timeframe", config.TIMEFRAME)
    limit = int(request.args.get("limit", 150))
    
    try:
        fetcher = DataFetcher(use_testnet=False)
        # Fetch OHLCV
        raw_candles = fetcher.exchange.fetch_ohlcv(config.SYMBOL, timeframe, limit=limit)
        df = generate_indicators(raw_candles)
        
        # Calculate Volume Profile over returned dataset
        vp = calculate_volume_profile(df)

        candles_data = []
        for index, row in df.iterrows():
            candles_data.append({
                "time": int(row["timestamp"].timestamp()),
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
                "volume": float(row["volume"]),
                "ema_9": float(row["ema_9"]) if not row.isna().get("ema_9", True) else None,
                "ema_20": float(row["ema_20"]) if not row.isna().get("ema_20", True) else None,
                "ema_50": float(row["ema_50"]) if not row.isna().get("ema_50", True) else None,
                "ema_200": float(row["ema_200"]) if not row.isna().get("ema_200", True) else None,
                "macd": float(row["macd_line"]) if not row.isna().get("macd_line", True) else None,
                "macd_signal": float(row["macd_signal"]) if not row.isna().get("macd_signal", True) else None,
                "macd_hist": float(row["macd_histogram"]) if not row.isna().get("macd_histogram", True) else None,
                "rsi": float(row["rsi"]) if not row.isna().get("rsi", True) else None,
            })

        # Fetch buy/sell trade markers
        trades = safe_query("SELECT id, timestamp, direction, entry_price, status, result_pnl FROM trades_log ORDER BY id DESC LIMIT 50")
        markers = []
        for t in trades:
            try:
                dt = datetime.fromisoformat(t["timestamp"])
                markers.append({
                    "time": int(dt.timestamp()),
                    "position": "belowBar" if t["direction"] == "LONG" else "aboveBar",
                    "color": "#00c076" if t["direction"] == "LONG" else "#ff3b69",
                    "shape": "arrowUp" if t["direction"] == "LONG" else "arrowDown",
                    "text": f"{t['direction']} @ {t['entry_price']}"
                })
            except Exception:
                pass

        # Extract latest POC, VAL, VAH safely
        latest_poc = float(df["poc"].dropna().iloc[-1]) if "poc" in df.columns and not df["poc"].dropna().empty else float(df["close"].iloc[-1])
        latest_val = float(df["val"].dropna().iloc[-1]) if "val" in df.columns and not df["val"].dropna().empty else float(df["close"].iloc[-1] * 0.98)
        latest_vah = float(df["vah"].dropna().iloc[-1]) if "vah" in df.columns and not df["vah"].dropna().empty else float(df["close"].iloc[-1] * 1.02)

        return jsonify({
            "status": "success",
            "timeframe": timeframe,
            "candles": candles_data,
            "markers": markers,
            "volume_profile": {
                "poc": latest_poc,
                "val": latest_val,
                "vah": latest_vah
            }
        })
    except Exception as e:
        logger.error(f"Candles API error: {e}")
        # Return DB cached or simulated fallback candles gracefully
        fallback_candles = []
        base_time = int(datetime.now(timezone.utc).timestamp()) - (100 * 300)
        base_price = 65000.0
        for i in range(100):
            p = base_price + (i % 5 * 20.0) - (i % 3 * 15.0)
            fallback_candles.append({
                "time": base_time + (i * 300),
                "open": p,
                "high": p + 30.0,
                "low": p - 30.0,
                "close": p + 10.0,
                "volume": 50.0,
                "ema_9": p, "ema_20": p, "ema_50": p, "ema_200": p,
                "macd": 5.0, "macd_signal": 4.0, "macd_hist": 1.0,
                "rsi": 55.0
            })
        return jsonify({
            "status": "warning",
            "message": f"Exchange candles fallback: {str(e)}",
            "timeframe": timeframe,
            "candles": fallback_candles,
            "markers": [],
            "volume_profile": {"poc": base_price, "val": base_price * 0.98, "vah": base_price * 1.02}
        })



@app.route("/api/orderbook")
def api_orderbook():
    """Fetch order book depth (bids and asks)."""
    try:
        fetcher = DataFetcher(use_testnet=False)
        orderbook = fetcher.exchange.fetch_order_book(config.SYMBOL, limit=15)
        
        bids = [{"price": float(b[0]), "amount": float(b[1]), "total": float(b[0]*b[1])} for b in orderbook.get("bids", [])]
        asks = [{"price": float(a[0]), "amount": float(a[1]), "total": float(a[0]*a[1])} for a in orderbook.get("asks", [])]
        
        return jsonify({
            "status": "success",
            "bids": bids,
            "asks": asks,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        logger.error(f"Orderbook API error: {e}")
        # Generate graceful fallback simulation depth
        base_price = 65000.0
        bids = [{"price": round(base_price - (i * 12.5), 2), "amount": round(0.15 + (i * 0.08), 4), "total": 10000} for i in range(10)]
        asks = [{"price": round(base_price + (i * 12.5), 2), "amount": round(0.12 + (i * 0.07), 4), "total": 10000} for i in range(10)]
        return jsonify({"status": "warning", "message": f"Exchange depth fallback: {e}", "bids": bids, "asks": asks})


# ============================================================================
# SECTION 2: BOT CONTROL ENDPOINTS
# ============================================================================
@app.route("/api/status")
def api_status():
    """Get bot live status, uptime, balance, and heartbeat."""
    bot_status = bot_manager.get_status()
    
    # Read heartbeat log from DB
    heartbeats = safe_query("SELECT timestamp, status, details FROM heartbeat_log ORDER BY id DESC LIMIT 1")
    last_heartbeat = heartbeats[0] if heartbeats else None

    # Read system health
    health_records = safe_query("SELECT balance, open_trade_pnl, internet_connected FROM system_health ORDER BY id DESC LIMIT 1")
    health = health_records[0] if health_records else {"balance": 10000.0, "open_trade_pnl": 0.0, "internet_connected": True}

    # Open trade check
    open_trade = safe_query_one("SELECT * FROM trades_log WHERE status = 'OPEN' ORDER BY id DESC LIMIT 1")

    # Today's realized PnL
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    todays_trades = safe_query("SELECT result_pnl FROM trades_log WHERE status='CLOSED' AND exit_timestamp LIKE ?", (f"{today_str}%",))
    todays_pnl = sum(float(t.get("result_pnl") or 0.0) for t in todays_trades)

    return jsonify({
        "status": "success",
        "bot": bot_status,
        "heartbeat": last_heartbeat,
        "health": health,
        "open_trade": open_trade,
        "todays_pnl": todays_pnl,
        "symbol": config.SYMBOL,
        "timeframe": config.TIMEFRAME,
        "trading_mode": config.TRADING_MODE,
        "allow_shorts": config.ALLOW_SHORTS
    })


@app.route("/api/bot/control", methods=["POST"])
def api_bot_control():
    """Start, Stop, Pause, Resume, or Kill-Switch the bot."""
    data = request.json or {}
    action = data.get("action", "").upper()
    confirmation_token = data.get("confirmation_token", "")

    if action == "START":
        res = bot_manager.start_bot()
    elif action == "STOP":
        res = bot_manager.stop_bot()
    elif action == "PAUSE":
        res = bot_manager.pause_bot()
    elif action == "RESUME":
        res = bot_manager.resume_bot()
    elif action == "KILL_SWITCH":
        # Requires 2FA confirmation token check
        if confirmation_token != "CONFIRM-KILL-SWITCH":
            return jsonify({"status": "error", "message": "Invalid 2FA confirmation token for Kill Switch."}), 403
        res = bot_manager.trigger_kill_switch()
    elif action == "DEACTIVATE_KILL_SWITCH":
        res = bot_manager.deactivate_kill_switch()
    else:
        return jsonify({"status": "error", "message": f"Unknown action: {action}"}), 400

    return jsonify(res)


@app.route("/api/strategy/config", methods=["GET", "POST"])
def api_strategy_config():
    """Get or update strategy and risk management parameters."""
    if request.method == "POST":
        data = request.json or {}
        user = data.get("user", "Trader")
        
        # Update config attributes in memory
        try:
            if "ema_fast_cross" in data: config.EMA_FAST_CROSS = int(data["ema_fast_cross"])
            if "ema_slow_cross" in data: config.EMA_SLOW_CROSS = int(data["ema_slow_cross"])
            if "ema_trend_filter" in data: config.EMA_TREND_FILTER = int(data["ema_trend_filter"])
            if "rsi_length" in data: config.RSI_LENGTH = int(data["rsi_length"])
            if "fixed_stop_loss_pct" in data: config.FIXED_STOP_LOSS_PCT = float(data["fixed_stop_loss_pct"])
            if "fixed_risk_reward_ratio" in data: config.FIXED_RISK_REWARD_RATIO = float(data["fixed_risk_reward_ratio"])
            if "risk_pct_per_trade" in data: config.RISK_PCT_PER_TRADE = float(data["risk_pct_per_trade"])
            if "daily_loss_limit_pct" in data: config.DAILY_LOSS_LIMIT_PCT = float(data["daily_loss_limit_pct"])
            if "max_concurrent_positions" in data: config.MAX_CONCURRENT_POSITIONS = int(data["max_concurrent_positions"])
            if "allow_shorts" in data: config.ALLOW_SHORTS = bool(data["allow_shorts"])
            if "use_rsi_filter" in data: config.USE_RSI_FILTER = bool(data["use_rsi_filter"])
            if "use_ema9_filter" in data: config.USE_EMA9_FILTER = bool(data["use_ema9_filter"])

            audit.log_audit_event("STRATEGY_CONFIG_UPDATE", user=user, details=data)
            audit.log_notification("INFO", "Settings", "Strategy parameters updated successfully.")
            return jsonify({"status": "success", "message": "Strategy parameters updated."})
        except Exception as e:
            return jsonify({"status": "error", "message": f"Failed to update config: {e}"}), 400

    # GET request returns current config
    return jsonify({
        "status": "success",
        "config": {
            "symbol": config.SYMBOL,
            "timeframe": config.TIMEFRAME,
            "ema_fast_cross": config.EMA_FAST_CROSS,
            "ema_slow_cross": config.EMA_SLOW_CROSS,
            "ema_trend_filter": config.EMA_TREND_FILTER,
            "rsi_length": config.RSI_LENGTH,
            "fixed_stop_loss_pct": config.FIXED_STOP_LOSS_PCT,
            "fixed_risk_reward_ratio": config.FIXED_RISK_REWARD_RATIO,
            "risk_pct_per_trade": config.RISK_PCT_PER_TRADE,
            "daily_loss_limit_pct": config.DAILY_LOSS_LIMIT_PCT,
            "max_concurrent_positions": config.MAX_CONCURRENT_POSITIONS,
            "allow_shorts": config.ALLOW_SHORTS,
            "use_rsi_filter": config.USE_RSI_FILTER,
            "use_ema9_filter": config.USE_EMA9_FILTER,
            "trading_mode": config.TRADING_MODE,
        }
    })


# ============================================================================
# SECTION 3: RISK MANAGEMENT ENDPOINTS
# ============================================================================
@app.route("/api/risk/calculate", methods=["POST"])
def api_risk_calculate():
    """Position sizing calculator."""
    data = request.json or {}
    account_balance = float(data.get("account_balance", 10000.0))
    risk_pct = float(data.get("risk_pct", config.RISK_PCT_PER_TRADE))
    entry_price = float(data.get("entry_price", 65000.0))
    stop_loss_price = float(data.get("stop_loss_price", 63700.0))

    if entry_price <= 0 or stop_loss_price <= 0 or entry_price == stop_loss_price:
        return jsonify({"status": "error", "message": "Invalid entry or stop loss price."}), 400

    risk_amount = account_balance * risk_pct
    price_distance = abs(entry_price - stop_loss_price)
    distance_pct = (price_distance / entry_price) * 100.0

    position_units = risk_amount / price_distance
    position_value = position_units * entry_price
    suggested_tp = entry_price + (price_distance * config.FIXED_RISK_REWARD_RATIO)

    return jsonify({
        "status": "success",
        "calculation": {
            "account_balance": account_balance,
            "risk_pct": risk_pct,
            "risk_amount_usdt": round(risk_amount, 2),
            "entry_price": entry_price,
            "stop_loss_price": stop_loss_price,
            "distance_pct": round(distance_pct, 2),
            "position_units_btc": round(position_units, 4),
            "position_value_usdt": round(position_value, 2),
            "suggested_take_profit": round(suggested_tp, 2),
            "risk_reward_ratio": config.FIXED_RISK_REWARD_RATIO
        }
    })


# ============================================================================
# SECTION 4: PERFORMANCE ANALYTICS ENDPOINTS
# ============================================================================
@app.route("/api/analytics")
def api_analytics():
    """Calculate key performance analytics: Win rate, Sharpe, drawdown, P&L."""
    trades = safe_query("SELECT * FROM trades_log WHERE status='CLOSED' ORDER BY id ASC")
    
    total_trades = len(trades)
    if total_trades == 0:
        return jsonify({
            "status": "success",
            "metrics": {
                "total_trades": 0, "win_rate_pct": 0.0, "pnl_today": 0.0, "pnl_7d": 0.0,
                "pnl_30d": 0.0, "pnl_all_time": 0.0, "avg_win": 0.0, "avg_loss": 0.0,
                "profit_factor": 0.0, "max_drawdown_pct": 0.0, "sharpe_ratio": 0.0
            },
            "equity_curve": [{"time": datetime.now(timezone.utc).isoformat(), "equity": 10000.0}]
        })

    pnls = [float(t.get("result_pnl") or 0.0) for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]

    win_rate = (len(wins) / total_trades) * 100.0 if total_trades > 0 else 0.0
    avg_win = sum(wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(losses) / len(losses)) if losses else 0.0
    profit_factor = (sum(wins) / abs(sum(losses))) if losses and sum(losses) != 0 else (sum(wins) if wins else 0.0)

    pnl_all_time = sum(pnls)

    # Time windowed PnL
    now = datetime.now(timezone.utc)
    today_str = now.strftime("%Y-%m-%d")
    d7_str = (now - timedelta(days=7)).isoformat()
    d30_str = (now - timedelta(days=30)).isoformat()

    pnl_today = sum(float(t["result_pnl"]) for t in trades if t.get("exit_timestamp", "").startswith(today_str))
    pnl_7d = sum(float(t["result_pnl"]) for t in trades if t.get("exit_timestamp", "") >= d7_str)
    pnl_30d = sum(float(t["result_pnl"]) for t in trades if t.get("exit_timestamp", "") >= d30_str)

    # Calculate Equity Curve & Max Drawdown
    equity = 10000.0
    equity_curve = [{"time": trades[0]["timestamp"], "equity": equity}]
    peak = equity
    max_dd = 0.0

    for t in trades:
        equity += float(t.get("result_pnl") or 0.0)
        equity_curve.append({"time": t.get("exit_timestamp") or t["timestamp"], "equity": equity})
        if equity > peak:
            peak = equity
        dd = (peak - equity) / peak if peak > 0 else 0.0
        if dd > max_dd:
            max_dd = dd

    # Sharpe Ratio estimation
    import numpy as np
    pnl_arr = np.array(pnls)
    std = np.std(pnl_arr)
    sharpe = float((np.mean(pnl_arr) / std * np.sqrt(252))) if std > 0 else 0.0

    return jsonify({
        "status": "success",
        "metrics": {
            "total_trades": total_trades,
            "win_rate_pct": round(win_rate, 2),
            "pnl_today": round(pnl_today, 2),
            "pnl_7d": round(pnl_7d, 2),
            "pnl_30d": round(pnl_30d, 2),
            "pnl_all_time": round(pnl_all_time, 2),
            "avg_win": round(avg_win, 2),
            "avg_loss": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown_pct": round(max_dd * 100.0, 2),
            "sharpe_ratio": round(sharpe, 2)
        },
        "equity_curve": equity_curve
    })


@app.route("/api/trades")
def api_trades():
    """Trade history endpoint supporting search and filtering."""
    status_filter = request.args.get("status", "ALL").upper()
    direction_filter = request.args.get("direction", "ALL").upper()
    query = request.args.get("query", "").strip()

    sql = "SELECT * FROM trades_log WHERE 1=1"
    params = []

    if status_filter != "ALL":
        sql += " AND status = ?"
        params.append(status_filter)
    if direction_filter != "ALL":
        sql += " AND direction = ?"
        params.append(direction_filter)
    if query:
        sql += " AND (symbol LIKE ? OR id LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%"])

    sql += " ORDER BY id DESC LIMIT 100"
    trades = safe_query(sql, tuple(params))
    return jsonify({"status": "success", "count": len(trades), "trades": trades})


@app.route("/api/trades/export")
def api_trades_export():
    """Export trades history as downloadable CSV file."""
    trades = safe_query("SELECT * FROM trades_log ORDER BY id DESC")
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Timestamp", "Symbol", "Direction", "Entry Price", "Stop Loss", "Take Profit", "Size", "Status", "Exit Price", "Exit Timestamp", "PnL (USDT)"])
    
    for t in trades:
        writer.writerow([
            t.get("id"), t.get("timestamp"), t.get("symbol"), t.get("direction"),
            t.get("entry_price"), t.get("stop_loss"), t.get("take_profit"), t.get("position_size"),
            t.get("status"), t.get("exit_price"), t.get("exit_timestamp"), t.get("result_pnl")
        ])
    
    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=btc_trading_bot_trades.csv"}
    )


# ============================================================================
# SECTION 5: BACKTESTING LAB ENDPOINTS
# ============================================================================
@app.route("/api/backtest/run", methods=["POST"])
def api_backtest_run():
    """Execute backtest on-demand."""
    data = request.json or {}
    start_date = data.get("start_date", "2024-01-01")
    end_date = data.get("end_date", "2024-06-01")
    strategy_name = data.get("strategy_name", "EMA_MACD_VP")
    initial_cash = float(data.get("initial_cash", 10000.0))

    try:
        # Run Backtrader backtest using src/backtester.py
        result = run_backtest(
            symbol=config.SYMBOL,
            timeframe=config.TIMEFRAME,
            start_date=start_date,
            end_date=end_date,
            initial_cash=initial_cash,
            allow_shorts=config.ALLOW_SHORTS
        )

        audit.log_audit_event("BACKTEST_RUN", user="Trader", details={"start_date": start_date, "end_date": end_date, "strategy": strategy_name})
        audit.log_notification("INFO", "Backtest", f"Backtest executed from {start_date} to {end_date}.")
        
        return jsonify({
            "status": "success",
            "backtest": result
        })
    except Exception as e:
        logger.error(f"Backtest execution error: {e}")
        return jsonify({"status": "error", "message": f"Backtest failed: {str(e)}"}), 500


# ============================================================================
# SECTION 6: ALERTS & MONITORING ENDPOINTS
# ============================================================================
@app.route("/api/alerts")
def api_alerts():
    """In-app notifications feed."""
    notifications = audit.get_notifications(limit=50)
    return jsonify({"status": "success", "notifications": notifications})


@app.route("/api/alerts/test", methods=["POST"])
def api_alerts_test():
    """Send test alert via Telegram / system notification."""
    data = request.json or {}
    channel = data.get("channel", "telegram").lower()

    if channel == "telegram":
        tg = TelegramAlert()
        msg = "🔔 <b>BTC Bot Alert Test</b>\n\nTest connection from your live dashboard is successful!"
        success = tg.send_message(msg)
        if success:
            audit.log_notification("INFO", "Telegram", "Telegram test message delivered.")
            return jsonify({"status": "success", "message": "Telegram test alert sent successfully."})
        else:
            return jsonify({"status": "error", "message": "Failed to send Telegram alert. Check bot token and chat ID."}), 400
    
    audit.log_notification("INFO", "System", "In-app test alert triggered.")
    return jsonify({"status": "success", "message": "In-app test notification sent."})


# ============================================================================
# SECTION 7: ACCOUNT & SECURITY ENDPOINTS
# ============================================================================
@app.route("/api/security/apikeys", methods=["GET", "POST"])
def api_security_apikeys():
    """Manage masked exchange API credentials."""
    if request.method == "POST":
        data = request.json or {}
        api_key = data.get("api_key", "").strip()
        secret_key = data.get("secret_key", "").strip()
        user = data.get("user", "Trader")

        if api_key:
            config.BINANCE_TESTNET_API_KEY = api_key
        if secret_key:
            config.BINANCE_TESTNET_SECRET_KEY = secret_key

        audit.log_audit_event("API_KEY_UPDATE", user=user, details={"api_key_masked": api_key[:4] + "****" if api_key else ""})
        audit.log_notification("WARNING", "Security", "Exchange API credentials updated.")
        return jsonify({"status": "success", "message": "API credentials updated successfully."})

    # Return masked view
    key = config.BINANCE_TESTNET_API_KEY
    masked_key = (key[:4] + "*" * 12 + key[-4:]) if len(key) > 8 else "NOT_CONFIGURED"
    return jsonify({
        "status": "success",
        "api_key_masked": masked_key,
        "exchange": config.EXCHANGE_NAME,
        "mode": config.TRADING_MODE
    })


@app.route("/api/security/audit")
def api_security_audit():
    """Fetch session & audit logs."""
    logs = audit.get_audit_logs(limit=50)
    return jsonify({"status": "success", "audit_logs": logs})


# ============================================================================
# SECTION 8: LOGS & DEBUGGING ENDPOINTS
# ============================================================================
@app.route("/api/logs")
def api_logs():
    """Read system logs with level filter and keyword search."""
    level = request.args.get("level", "ALL").upper()
    search = request.args.get("search", "").lower()
    limit = int(request.args.get("limit", 150))

    log_files = [config.LOG_FILE, config.BASE_DIR / "data" / "live_runner.log"]
    lines = []

    for fpath in log_files:
        if fpath.exists():
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    file_lines = f.readlines()
                    for line in file_lines:
                        l_lower = line.lower()
                        if level != "ALL" and level not in line:
                            continue
                        if search and search not in l_lower:
                            continue
                        lines.append(line.strip())
            except Exception as e:
                logger.error(f"Error reading log file {fpath}: {e}")

    # Return last N lines
    recent_lines = lines[-limit:] if len(lines) > limit else lines
    recent_lines.reverse()

    # Active system errors from DB
    system_errors = safe_query("SELECT id, timestamp, error_message FROM system_errors ORDER BY id DESC LIMIT 10")

    return jsonify({
        "status": "success",
        "log_count": len(recent_lines),
        "logs": recent_lines,
        "system_errors": system_errors
    })


@app.route("/api/logs/diagnostic_report")
def api_logs_diagnostic_report():
    """Generate complete copyable error & system status diagnostic report."""
    sys_errors = safe_query("SELECT timestamp, error_message FROM system_errors ORDER BY id DESC LIMIT 5")
    audit_events = audit.get_audit_logs(limit=5)
    
    report_lines = [
        "=== BTC ALGO TRADING BOT DIAGNOSTIC REPORT ===",
        f"Generated At: {datetime.now(timezone.utc).isoformat()}",
        f"Bot Name: {config.BOT_NAME}",
        f"Exchange: {config.EXCHANGE_NAME} ({config.TRADING_MODE})",
        f"Symbol: {config.SYMBOL} | Timeframe: {config.TIMEFRAME}",
        f"Python Version: {sys.version.split()[0]}",
        f"Process Running: {bot_manager.is_running()}",
        f"Kill Switch Active: {config.KILL_SWITCH_FILE.exists()}",
        "\n--- RECENT SYSTEM ERRORS ---"
    ]

    if sys_errors:
        for err in sys_errors:
            report_lines.append(f"[{err['timestamp']}] {err['error_message']}")
    else:
        report_lines.append("No system errors recorded in database.")

    report_lines.append("\n--- RECENT AUDIT EVENTS ---")
    for evt in audit_events:
        report_lines.append(f"[{evt['timestamp']}] {evt['action']} by {evt['user']}")

    return jsonify({
        "status": "success",
        "report": "\n".join(report_lines)
    })


# ============================================================================
# MAIN ENTRYPOINT
# ============================================================================
if __name__ == "__main__":
    port = int(os.getenv("PORT", 5050))
    print(f"\n=======================================================")
    print(f"🚀 BTC Algo Trading Bot UI Dashboard")
    print(f"URL: http://127.0.0.1:{port}")
    print(f"=======================================================\n")
    app.run(host="0.0.0.0", port=port, debug=False)