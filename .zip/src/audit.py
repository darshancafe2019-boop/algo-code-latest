import sqlite3
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Dict, Any, List

from src import config

logger = logging.getLogger("Audit")

def init_audit_db():
    """Ensure audit_log table exists in the database."""
    conn = sqlite3.connect(str(config.DB_PATH))
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            action TEXT NOT NULL,
            user TEXT NOT NULL,
            details TEXT,
            ip_address TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS alert_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            level TEXT NOT NULL,
            category TEXT NOT NULL,
            message TEXT NOT NULL,
            is_read INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()

def log_audit_event(action: str, user: str = "Trader", details: Optional[Dict[str, Any]] = None, ip_address: str = "127.0.0.1"):
    """Record an audit log entry."""
    try:
        init_audit_db()
        conn = sqlite3.connect(str(config.DB_PATH))
        cursor = conn.cursor()
        now_str = datetime.now(timezone.utc).isoformat()
        details_str = json.dumps(details) if details else ""
        cursor.execute(
            "INSERT INTO audit_log (timestamp, action, user, details, ip_address) VALUES (?, ?, ?, ?, ?)",
            (now_str, action, user, details_str, ip_address)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Failed to record audit event: {e}")

def get_audit_logs(limit: int = 50) -> List[Dict[str, Any]]:
    """Fetch recent audit log entries."""
    try:
        init_audit_db()
        conn = sqlite3.connect(str(config.DB_PATH))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows
    except Exception as e:
        logger.error(f"Failed to fetch audit logs: {e}")
        return []

def log_notification(level: str, category: str, message: str):
    """Record an in-app notification event."""
    try:
        init_audit_db()
        conn = sqlite3.connect(str(config.DB_PATH))
        cursor = conn.cursor()
        now_str = datetime.now(timezone.utc).isoformat()
        cursor.execute(
            "INSERT INTO alert_notifications (timestamp, level, category, message, is_read) VALUES (?, ?, ?, ?, 0)",
            (now_str, level.upper(), category, message)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Failed to record notification: {e}")

def get_notifications(limit: int = 50) -> List[Dict[str, Any]]:
    """Fetch recent in-app notifications."""
    try:
        init_audit_db()
        conn = sqlite3.connect(str(config.DB_PATH))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM alert_notifications ORDER BY id DESC LIMIT ?", (limit,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows
    except Exception as e:
        logger.error(f"Failed to fetch notifications: {e}")
        return []
