import json
import logging
import shutil
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from src import config

logger = logging.getLogger("DB")


def get_connection() -> sqlite3.Connection:
    """Create and return a connection to the SQLite database."""
    conn = sqlite3.connect(str(config.DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    """Create or verify the SQLite tables used by the bot."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS signals_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            symbol TEXT NOT NULL,
            signal_type TEXT NOT NULL,
            price REAL NOT NULL,
            filters_status TEXT,
            is_blocked INTEGER DEFAULT 0,
            reason TEXT,
            context TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS trades_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            symbol TEXT NOT NULL,
            direction TEXT NOT NULL,
            entry_price REAL NOT NULL,
            stop_loss REAL NOT NULL,
            take_profit REAL NOT NULL,
            position_size REAL NOT NULL,
            status TEXT DEFAULT 'OPEN',
            exit_price REAL,
            exit_timestamp TEXT,
            result_pnl REAL DEFAULT 0.0,
            metadata TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS system_errors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            error_message TEXT NOT NULL,
            stack_trace TEXT,
            module TEXT,
            function_name TEXT,
            retry_count INTEGER DEFAULT 0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS heartbeat_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            status TEXT NOT NULL,
            details TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS bot_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            status TEXT NOT NULL,
            exchange_status TEXT,
            telegram_status TEXT,
            database_status TEXT,
            details TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS performance_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            total_trades INTEGER DEFAULT 0,
            winning_trades INTEGER DEFAULT 0,
            losing_trades INTEGER DEFAULT 0,
            win_rate REAL DEFAULT 0.0,
            loss_rate REAL DEFAULT 0.0,
            average_win REAL DEFAULT 0.0,
            average_loss REAL DEFAULT 0.0,
            largest_win REAL DEFAULT 0.0,
            largest_loss REAL DEFAULT 0.0,
            profit_factor REAL DEFAULT 0.0,
            expectancy REAL DEFAULT 0.0,
            current_drawdown REAL DEFAULT 0.0,
            max_drawdown REAL DEFAULT 0.0,
            daily_return REAL DEFAULT 0.0,
            weekly_return REAL DEFAULT 0.0,
            monthly_return REAL DEFAULT 0.0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS api_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            endpoint TEXT,
            success INTEGER DEFAULT 0,
            latency_ms REAL,
            details TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS telegram_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            success INTEGER DEFAULT 0,
            message TEXT,
            error TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS system_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            cpu_percent REAL,
            ram_mb REAL,
            internet_connected INTEGER DEFAULT 0,
            latency_ms REAL,
            balance REAL,
            equity REAL,
            current_position REAL,
            running_time_seconds REAL,
            status TEXT
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS daily_statistics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            date_key TEXT NOT NULL,
            total_trades INTEGER DEFAULT 0,
            winning_trades INTEGER DEFAULT 0,
            losing_trades INTEGER DEFAULT 0,
            win_rate REAL DEFAULT 0.0,
            daily_pnl REAL DEFAULT 0.0,
            balance REAL,
            equity REAL
        )
        """
    )

    conn.commit()
    conn.close()
    logger.info("SQLite database tables verified/created.")


def _json_dumps(value: Optional[Dict[str, Any]]) -> str:
    return json.dumps(value or {}, default=str)


def log_signal(
    symbol: str,
    signal_type: str,
    price: float,
    filters_status: dict,
    is_blocked: bool,
    reason: str,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """Persist a strategy signal evaluation to the database."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO signals_log (timestamp, symbol, signal_type, price, filters_status, is_blocked, reason, context)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (now_str, symbol, signal_type, price, _json_dumps(filters_status), 1 if is_blocked else 0, reason, _json_dumps(context)),
        )
        conn.commit()
        conn.close()
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.error("Error logging signal to DB: %s", exc)


def log_trade_entry(
    symbol: str,
    direction: str,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    position_size: float,
    metadata: Optional[Dict[str, Any]] = None,
) -> int:
    """Log a new trade entry and return the generated trade row ID."""
    trade_id = -1
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO trades_log (timestamp, symbol, direction, entry_price, stop_loss, take_profit, position_size, status, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)
            """,
            (now_str, symbol, direction, entry_price, stop_loss, take_profit, position_size, _json_dumps(metadata)),
        )
        conn.commit()
        trade_id = cursor.lastrowid
        conn.close()
        logger.info("Logged trade entry in DB. ID: %s", trade_id)
    except Exception as exc:
        logger.error("Error logging trade entry to DB: %s", exc)
    return trade_id


def log_trade_exit(trade_id: int, exit_price: float, result_pnl: float, reason: str = "") -> None:
    """Close an open trade and persist its finalized PnL."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            UPDATE trades_log
            SET status = 'CLOSED', exit_price = ?, exit_timestamp = ?, result_pnl = ?, metadata = COALESCE(metadata, '{}') || ?
            WHERE id = ?
            """,
            (exit_price, now_str, result_pnl, json.dumps({"exit_reason": reason}), trade_id),
        )
        conn.commit()
        conn.close()
        logger.info("Updated trade exit in DB for ID: %s", trade_id)
    except Exception as exc:
        logger.error("Error logging trade exit to DB: %s", exc)


def log_error(error_message: str, stack_trace: str = "", module: str = "", function_name: str = "", retry_count: int = 0) -> None:
    """Persist an unexpected error or API failure."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO system_errors (timestamp, error_message, stack_trace, module, function_name, retry_count)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (now_str, error_message, stack_trace, module, function_name, retry_count),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging system error to DB: %s", exc)


def log_heartbeat(status: str, details: Optional[Dict[str, Any]] = None) -> None:
    """Record a heartbeat from the runner cycle."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO heartbeat_log (timestamp, status, details)
            VALUES (?, ?, ?)
            """,
            (now_str, status, _json_dumps(details)),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging heartbeat to DB: %s", exc)


def log_bot_status(status: str, exchange_status: str, telegram_status: str, database_status: str, details: Optional[Dict[str, Any]] = None) -> None:
    """Persist a snapshot of the bot health."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO bot_status (timestamp, status, exchange_status, telegram_status, database_status, details)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (now_str, status, exchange_status, telegram_status, database_status, _json_dumps(details)),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging bot status: %s", exc)


def log_api_event(endpoint: str, success: bool, latency_ms: Optional[float], details: Optional[Dict[str, Any]] = None) -> None:
    """Record exchange or API interactions."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO api_logs (timestamp, endpoint, success, latency_ms, details)
            VALUES (?, ?, ?, ?, ?)
            """,
            (now_str, endpoint, 1 if success else 0, latency_ms, _json_dumps(details)),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging API event: %s", exc)


def log_telegram_event(success: bool, message: str, error: str = "") -> None:
    """Persist Telegram delivery attempts."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO telegram_logs (timestamp, success, message, error)
            VALUES (?, ?, ?, ?)
            """,
            (now_str, 1 if success else 0, message[:400], error[:400]),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging Telegram event: %s", exc)


def log_system_health(
    cpu_percent: Optional[float],
    ram_mb: Optional[float],
    internet_connected: bool,
    latency_ms: Optional[float],
    balance: Optional[float],
    equity: Optional[float],
    current_position: Optional[float],
    running_time_seconds: Optional[float],
    status: str,
) -> None:
    """Persist a health snapshot containing runtime and connectivity metrics."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        cursor.execute(
            """
            INSERT INTO system_health (timestamp, cpu_percent, ram_mb, internet_connected, latency_ms, balance, equity, current_position, running_time_seconds, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (now_str, cpu_percent, ram_mb, 1 if internet_connected else 0, latency_ms, balance, equity, current_position, running_time_seconds, status),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging system health: %s", exc)


def log_daily_statistics(stats: Dict[str, Any]) -> None:
    """Persist a daily summary snapshot."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now_str = datetime.utcnow().isoformat()
        date_key = datetime.utcnow().strftime("%Y-%m-%d")
        cursor.execute(
            """
            INSERT INTO daily_statistics (timestamp, date_key, total_trades, winning_trades, losing_trades, win_rate, daily_pnl, balance, equity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                now_str,
                date_key,
                stats.get("total_trades", 0),
                stats.get("winning_trades", 0),
                stats.get("losing_trades", 0),
                stats.get("win_rate", 0.0),
                stats.get("daily_pnl", 0.0),
                stats.get("balance"),
                stats.get("equity"),
            ),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.error("Error logging daily statistics: %s", exc)


def backup_database() -> Optional[Path]:
    """Create a timestamped backup copy of the SQLite database."""
    if not config.DB_BACKUP_ENABLED:
        return None
    try:
        backup_dir = config.BACKUP_PATH
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        destination = backup_dir / f"trading_bot_{timestamp}.db"
        shutil.copy2(str(config.DB_PATH), str(destination))
        logger.info("Database backup created at %s", destination)
        return destination
    except Exception as exc:
        logger.error("Database backup failed: %s", exc)
        return None


def check_database_integrity() -> Tuple[bool, str]:
    """Run a SQLite integrity check and return the status."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        row = cursor.execute("PRAGMA quick_check").fetchone()
        conn.close()
        if row and row[0] == "ok":
            return True, "ok"
        return False, str(row[0]) if row else "unknown"
    except Exception as exc:
        logger.error("Database integrity check failed: %s", exc)
        return False, str(exc)


def get_todays_pnl(symbol: str = config.SYMBOL) -> float:
    """Aggregate finalized PnL for trades closed today (UTC)."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        today_date_str = datetime.utcnow().strftime("%Y-%m-%d")
        cursor.execute(
            """
            SELECT SUM(result_pnl) as total_pnl
            FROM trades_log
            WHERE symbol = ? AND status = 'CLOSED' AND exit_timestamp LIKE ?
            """,
            (symbol, f"{today_date_str}%"),
        )
        row = cursor.fetchone()
        conn.close()
        total_pnl = row["total_pnl"]
        return float(total_pnl) if total_pnl is not None else 0.0
    except Exception as exc:
        logger.error("Error getting today's PnL from DB: %s", exc)
        return 0.0


def get_daily_summary_stats() -> dict:
    """Retrieve execution stats for the last 24 hours (UTC)."""
    stats = {"cycles_run": 0, "signals_fired": [], "errors_count": 0}
    try:
        conn = get_connection()
        cursor = conn.cursor()
        now = datetime.utcnow()
        day_ago = (now - timedelta(days=1)).isoformat()
        cursor.execute("SELECT COUNT(*) as count FROM heartbeat_log WHERE timestamp >= ?", (day_ago,))
        row = cursor.fetchone()
        stats["cycles_run"] = row["count"] if row else 0
        cursor.execute("SELECT timestamp, signal_type, price, reason FROM signals_log WHERE timestamp >= ? AND signal_type != 'HOLD'", (day_ago,))
        stats["signals_fired"] = [dict(r) for r in cursor.fetchall()]
        cursor.execute("SELECT COUNT(*) as count FROM system_errors WHERE timestamp >= ?", (day_ago,))
        row = cursor.fetchone()
        stats["errors_count"] = row["count"] if row else 0
        conn.close()
    except Exception as exc:
        logger.error("Error fetching daily summary stats: %s", exc)
    return stats

