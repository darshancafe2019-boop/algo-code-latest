import pandas as pd
import numpy as np
import logging
from typing import Tuple, Dict, Optional
from src import config

logger = logging.getLogger("Indicators")


def get_timeframe_minutes(timeframe: Optional[str] = None) -> int:
    """Map supported Binance timeframes to approximate minute counts."""
    tf = (timeframe or config.TIMEFRAME or "5m").lower()
    mapping = {
        "1m": 1,
        "3m": 3,
        "5m": 5,
        "15m": 15,
        "30m": 30,
        "1h": 60,
        "2h": 120,
        "4h": 240,
        "6h": 360,
        "8h": 480,
        "12h": 720,
        "1d": 1440,
    }
    if tf not in mapping:
        logger.warning("Unsupported timeframe %s. Falling back to 5m mapping.", tf)
        return mapping.get("1h", 60)
    return mapping[tf]


def get_lookback_candles(timeframe: Optional[str] = None, lookback_days: Optional[int] = None) -> int:
    """Convert a lookback in days to a candle count for the selected timeframe."""
    tf = (timeframe or config.TIMEFRAME or "5m").lower()
    if tf not in {
        "1m",
        "3m",
        "5m",
        "15m",
        "30m",
        "1h",
        "2h",
        "4h",
        "6h",
        "8h",
        "12h",
        "1d",
    }:
        logger.warning("Unsupported timeframe %s. Falling back to a 30-day 1h lookback.", tf)
        return 720

    days = lookback_days if lookback_days is not None else config.VP_LOOKBACK_DAYS
    minutes = get_timeframe_minutes(tf)
    candles = max(24 * 60 // minutes, 1) * int(days)
    return int(candles)


def _ema(series: pd.Series, length: int) -> pd.Series:
    """Calculate an EMA with a simple seed at the first valid window."""
    if length <= 1:
        return series.copy()

    ema_values = pd.Series(index=series.index, dtype=float)
    if len(series) == 0:
        return ema_values

    alpha = 2.0 / (length + 1.0)
    first_valid = series.iloc[:length].dropna()
    if first_valid.empty:
        return ema_values

    seed_value = float(first_valid.mean())
    ema_values.iloc[length - 1] = seed_value

    prev_ema = seed_value
    for idx in range(length, len(series)):
        value = series.iloc[idx]
        if pd.isna(value):
            ema_values.iloc[idx] = np.nan
            continue
        prev_ema = prev_ema + alpha * (float(value) - prev_ema)
        ema_values.iloc[idx] = prev_ema

    return ema_values


def calculate_emas(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates EMA 9, 20, 50, and 200 on closing prices.
    
    Args:
        df (pd.DataFrame): Dataframe with 'close' column.
        
    Returns:
        pd.DataFrame: Dataframe with added EMA columns.
    """
    df['ema_9'] = _ema(df['close'], config.EMA_FAST_CROSS)
    df['ema_20'] = _ema(df['close'], config.EMA_SLOW_CROSS)
    df['ema_50'] = _ema(df['close'], config.EMA_SUPPORT)
    df['ema_200'] = _ema(df['close'], config.EMA_TREND_FILTER)
    return df

def calculate_macd(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates MACD Line, Signal Line, and Histogram.
    Standardizes column names.
    
    Args:
        df (pd.DataFrame): Dataframe with 'close' column.
        
    Returns:
        pd.DataFrame: Dataframe with standard columns: macd_line, macd_signal, macd_hist.
    """
    fast_ema = _ema(df['close'], config.MACD_FAST)
    slow_ema = _ema(df['close'], config.MACD_SLOW)
    macd_line = fast_ema - slow_ema
    signal_line = macd_line.ewm(span=config.MACD_SIGNAL, adjust=False, min_periods=config.MACD_SIGNAL).mean()
    hist_line = macd_line - signal_line

    df['macd_line'] = macd_line
    df['macd_signal'] = signal_line
    df['macd_hist'] = hist_line
    return df


def calculate_rsi(df: pd.DataFrame, length: int = 14, source: str = 'close') -> pd.DataFrame:
    """
    Calculates RSI on the given source price series.

    Args:
        df (pd.DataFrame): Dataframe with source column.
        length (int): RSI lookback length.
        source (str): Column name to use for RSI calculation.

    Returns:
        pd.DataFrame: Dataframe with added 'rsi' column.
    """
    delta = df[source].diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)

    avg_gain = gain.rolling(window=length, min_periods=length).mean()
    avg_loss = loss.rolling(window=length, min_periods=length).mean()

    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    rsi = 100.0 - (100.0 / (1.0 + rs))

    df['rsi'] = rsi
    return df


def _calculate_value_area(bin_volumes: Dict[int, float], value_area_pct: float) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """
    Helper function to calculate POC, VAL, VAH from a volume-by-bin dictionary.
    
    Args:
        bin_volumes (dict): Map of bin start price (int) to volume (float).
        value_area_pct (float): Percentage of volume within the Value Area (e.g. 0.70).
        
    Returns:
        tuple: (poc, val, vah) representing POC price, VAL price, and VAH price.
    """
    # Remove bins with negligible volumes to optimize search
    active_bins = {k: v for k, v in bin_volumes.items() if v > 1e-5}
    if not active_bins:
        return None, None, None

    sorted_bins = sorted(active_bins.keys())
    
    # POC (Point of Control) is the bin with the highest volume
    poc_bin = max(active_bins, key=active_bins.get)
    poc_idx = sorted_bins.index(poc_bin)
    
    total_volume = sum(active_bins.values())
    target_volume = total_volume * value_area_pct
    
    current_volume = active_bins[poc_bin]
    
    # Expansion pointers starting at POC
    low_idx = poc_idx
    high_idx = poc_idx
    
    while current_volume < target_volume:
        vol_below = 0.0
        vol_above = 0.0
        
        if low_idx > 0:
            vol_below = active_bins[sorted_bins[low_idx - 1]]
        if high_idx < len(sorted_bins) - 1:
            vol_above = active_bins[sorted_bins[high_idx + 1]]
            
        if vol_below == 0.0 and vol_above == 0.0:
            break  # No more volume to expand to
            
        # Add the larger volume bin and move pointer
        if vol_below >= vol_above:
            low_idx -= 1
            current_volume += vol_below
        else:
            high_idx += 1
            current_volume += vol_above
            
    val = sorted_bins[low_idx]
    vah = sorted_bins[high_idx]
    
    return int(poc_bin), int(val), int(vah)

def calculate_volume_profile(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates Point of Control (POC), Value Area Low (VAL), and Value Area High (VAH)
    over a rolling lookback window using the High-Low range split method.
    
    For each candle, its volume is distributed equally across all price bins
    overlapping its High-Low price range.
    
    Args:
        df (pd.DataFrame): Dataframe with 'high', 'low', 'volume', and 'timestamp' columns.
                           Timestamps must be sorted ascending.
                           
    Returns:
        pd.DataFrame: Dataframe with added columns: 'poc', 'val', 'vah'.
    """
    # 1. Determine lookback window size in candles
    # Get average timeframe difference in hours to convert lookback_days
    # For robust calculation, we estimate from config settings.
    timeframe = config.TIMEFRAME
    if timeframe == '1h':
        lookback_candles = config.VP_LOOKBACK_DAYS * 24
    elif timeframe == '4h':
        lookback_candles = config.VP_LOOKBACK_DAYS * 6
    else:
        # Fallback dynamic calculation
        logger.warning(f"Unknown timeframe {timeframe}. Defaulting lookback to 30 days assuming 1h bars (720).")
        lookback_candles = 720
        
    bin_size = config.VP_BIN_SIZE_USDT
    value_area_pct = config.VP_VALUE_AREA_PCT

    pocs = [np.nan] * len(df)
    vals = [np.nan] * len(df)
    vahs = [np.nan] * len(df)
    
    # Pre-distribute each candle's volume to avoid repeating this calculation
    candle_distributions = []
    for idx, row in df.iterrows():
        high = float(row['high'])
        low = float(row['low'])
        vol = float(row['volume'])
        dist = {}
        
        # If High-Low range is 0 (or close to it), place all volume in one bin
        if high <= low + 1e-4:
            bin_val = int(low // bin_size) * int(bin_size)
            dist[bin_val] = vol
        else:
            low_bin = int(low // bin_size) * int(bin_size)
            high_bin = int(high // bin_size) * int(bin_size)
            
            # Find the range of bins
            num_bins = int((high_bin - low_bin) / bin_size) + 1
            vol_per_bin = vol / num_bins
            for b in range(low_bin, high_bin + int(bin_size), int(bin_size)):
                dist[b] = vol_per_bin
                
        candle_distributions.append(dist)
        
    # Running volume profile dictionary
    running_profile = {}
    
    # 2. Build initial window
    initial_limit = min(lookback_candles, len(df))
    for idx in range(initial_limit):
        dist = candle_distributions[idx]
        for b, vol in dist.items():
            running_profile[b] = running_profile.get(b, 0.0) + vol
            
    # Calculate indicators for the end of the initial window
    if len(df) >= lookback_candles:
        poc, val, vah = _calculate_value_area(running_profile, value_area_pct)
        pocs[lookback_candles - 1] = poc
        vals[lookback_candles - 1] = val
        vahs[lookback_candles - 1] = vah
        
    # 3. Slide the window
    for idx in range(lookback_candles, len(df)):
        # Remove the candle that fell out of lookback
        out_dist = candle_distributions[idx - lookback_candles]
        for b, vol in out_dist.items():
            if b in running_profile:
                running_profile[b] -= vol
                if running_profile[b] <= 1e-5:
                    del running_profile[b]
                    
        # Add the new candle entering the window
        in_dist = candle_distributions[idx]
        for b, vol in in_dist.items():
            running_profile[b] = running_profile.get(b, 0.0) + vol
            
        # Calculate new profile boundaries
        poc, val, vah = _calculate_value_area(running_profile, value_area_pct)
        pocs[idx] = poc
        vals[idx] = val
        vahs[idx] = vah
        
    df['poc'] = pocs
    df['val'] = vals
    df['vah'] = vahs
    
    return df

def generate_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes all EMAs, MACD, and Volume Profile on the provided dataframe.
    
    Args:
        df (pd.DataFrame): Dataframe containing historical OHLCV data.
        
    Returns:
        pd.DataFrame: Dataframe with all indicator columns populated.
    """
    df = calculate_emas(df)
    df = calculate_macd(df)
    df = calculate_volume_profile(df)

    if config.PRINT_INDICATORS:
        latest = df.iloc[-1]
        logger.info(
            "Indicators computed | close=%.2f ema_9=%.2f ema_20=%.2f ema_50=%.2f ema_200=%.2f macd=%.4f poc=%s val=%s vah=%s",
            float(latest['close']),
            float(latest['ema_9']),
            float(latest['ema_20']),
            float(latest['ema_50']),
            float(latest['ema_200']),
            float(latest['macd_line']),
            latest['poc'],
            latest['val'],
            latest['vah'],
        )
    return df
