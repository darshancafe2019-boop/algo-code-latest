import sys
import logging
import time
from typing import Optional, Dict, Any
import traceback
from pathlib import Path
from datetime import datetime
from apscheduler.schedulers.blocking import BlockingScheduler

# Add project root to path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from src import config
from src.data_fetcher import DataFetcher
from src.indicators import generate_indicators
from src.strategy import Strategy
from src.risk_manager import RiskManager
from src.telegram_alert import TelegramAlert
from src.monitoring import MonitoringService
from src import db
from src.execution import ExecutionEngine

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(config.BASE_DIR / "data" / "live_runner.log")
    ]
)
logger = logging.getLogger("LiveRunner")


class CycleContext:
    """Simple container for the current evaluation context."""

    def __init__(self) -> None:
        self.started_at = datetime.utcnow()
        self.balance = 10000.0
        self.close_price = 0.0
        self.signal = "HOLD"
        self.decision = "HOLD"
        self.open_trade = None
        self.status = "OK"
        self.details = {}

class LiveRunner:
    """
    Orchestrates the scheduled execution cycle of the BTC Algo Trading Bot.
    Runs in alert-only paper trading mode connected to Binance Testnet.
    """

    def __init__(self):
        db.init_db()
        self.strategy = Strategy()
        self.risk_manager = RiskManager()
        self.telegram = TelegramAlert()
        self.monitoring = MonitoringService()
        self.retry_count = 0
        
        # Testnet data fetcher for balance checks and order simulation
        self.testnet_fetcher = DataFetcher(use_testnet=True)
        # Execution engine for real orders on Binance Testnet (spot)
        self.executor = ExecutionEngine(self.testnet_fetcher.exchange)
        # Mainnet fetcher for reliable live candles
        self.mainnet_fetcher = DataFetcher(use_testnet=False)

    def process_cycle(self):
        """Execute one bot evaluation cycle with diagnostics and safety checks."""
        logger.info("Starting signal check cycle...")
        context = CycleContext()
        status = "OK"

        try:
            if self.risk_manager.is_kill_switch_active():
                logger.warning("Kill switch file active. Skipping cycle.")
                self.telegram.send_message("⚠️ *BTC Trading Bot alert*: Cycle skipped. kill_switch.flag is present in the workspace.")
                return

            try:
                balance = self.testnet_fetcher.fetch_testnet_balance()
                context.balance = float(balance)
            except Exception as exc:
                logger.warning("Could not connect to Binance Testnet: %s. Falling back to mock balance of $10,000 USDT.", exc)
                balance = 10000.0
                context.balance = balance

            if config.FORCE_TEST_SIGNAL:
                logger.info("FORCE_TEST_SIGNAL is enabled; injecting a LONG signal for Telegram testing.")
                context.signal = "LONG"
                context.decision = "LONG"

            logger.info("Fetching recent candles for %s (%s)...", config.SYMBOL, config.TIMEFRAME)
            df = self.mainnet_fetcher.fetch_live_ohlcv(config.SYMBOL, config.TIMEFRAME, limit=1000)

            if df.empty or len(df) < 200:
                logger.error("Fetched insufficient historical candles for indicator calculation.")
                status = "WARN"
                return

            df = generate_indicators(df)
            eval_idx = len(df) - 2
            candle_time = pd_timestamp_to_str(df.iloc[eval_idx]['timestamp'])
            close_price = float(df.iloc[eval_idx]['close'])
            high_price = float(df.iloc[eval_idx]['high'])
            low_price = float(df.iloc[eval_idx]['low'])
            context.close_price = close_price
            logger.info("Evaluating strategy on completed candle: %s at Close price: %.2f", candle_time, close_price)

            active_trade = get_active_trade()
            context.open_trade = active_trade
            if active_trade:
                trade_id = active_trade['id']
                direction = active_trade['direction']
                entry_price = active_trade['entry_price']
                sl_price = active_trade['stop_loss']
                tp_price = active_trade['take_profit']
                size = active_trade['position_size']
                logger.info("Active trade found in DB (ID: %s, %s, Entry: %.2f, SL: %.2f, TP: %.2f)", trade_id, direction, entry_price, sl_price, tp_price)

                exit_triggered = False
                exit_price = 0.0
                exit_pnl = 0.0
                exit_reason = ""

                if direction == "LONG":
                    if low_price <= sl_price:
                        exit_triggered = True
                        exit_price = sl_price
                        exit_pnl = (exit_price - entry_price) * size
                        exit_reason = "STOP LOSS"
                    elif high_price >= tp_price:
                        exit_triggered = True
                        exit_price = tp_price
                        exit_pnl = (exit_price - entry_price) * size
                        exit_reason = "TAKE PROFIT"
                elif direction == "SHORT":
                    if high_price >= sl_price:
                        exit_triggered = True
                        exit_price = sl_price
                        exit_pnl = (entry_price - exit_price) * size
                        exit_reason = "STOP LOSS"
                    elif low_price <= tp_price:
                        exit_triggered = True
                        exit_price = tp_price
                        exit_pnl = (entry_price - exit_price) * size
                        exit_reason = "TAKE PROFIT"

                if exit_triggered:
                    logger.info("Exit triggered: %s hit at %.2f. PnL: %.2f USDT.", exit_reason, exit_price, exit_pnl)
                    if direction == "LONG":
                        # On LONG exits, perform a real market SELL on Binance Testnet
                        try:
                            order = self.executor.market_sell(config.SYMBOL, size, exit_price)
                            exit_price = float(order['average_price'])
                            filled = float(order['filled_amount'])
                            exit_pnl = (exit_price - entry_price) * filled
                            db.log_trade_exit(trade_id, exit_price, exit_pnl, exit_reason)
                            self.telegram.send_message(
                                f"🚪 *TRADE CLOSED - Real Execution*\n"
                                f"• *Symbol*: {config.SYMBOL}\n"
                                f"• *Direction*: {direction}\n"
                                f"• *Exit Reason*: {exit_reason}\n"
                                f"• *Exit Price*: {exit_price:.2f}\n"
                                f"• *Net PnL*: {exit_pnl:+.2f} USDT\n"
                                f"• *Order ID*: {order.get('order_id') or 'N/A'}"
                            )
                            active_trade = None
                        except Exception as exc:
                            stack = traceback.format_exc()
                            db.log_error(str(exc), stack, module="live_runner", function_name="process_cycle", retry_count=self.retry_count)
                            try:
                                self.telegram.send_message(
                                    f"⚠️ *EXECUTION FAILED (Exit - LONG)*\n"
                                    f"• *Symbol*: {config.SYMBOL}\n"
                                    f"• *Reason*: {str(exc)}\n"
                                    f"• *Action*: Manual intervention required. Trade not closed in DB."
                                )
                            except Exception:
                                logger.error("Failed to send Telegram alert for execution failure.")
                            # Skip logging the trade exit to avoid fabricating a close
                    else:
                        # SHORT exits remain alert-only (spot cannot short in Testnet)
                        db.log_trade_exit(trade_id, exit_price, exit_pnl, exit_reason)
                        self.telegram.send_message(
                            f"🚪 *TRADE CLOSED - Alert Only (SHORT — spot can't short)*\n"
                            f"• *Symbol*: {config.SYMBOL}\n"
                            f"• *Direction*: {direction}\n"
                            f"• *Exit Reason*: {exit_reason}\n"
                            f"• *Exit Price*: {exit_price:.2f}\n"
                            f"• *Net PnL*: {exit_pnl:+.2f} USDT"
                        )
                        active_trade = None
                else:
                    logger.info("Active trade SL/TP not hit. Holding position.")
                    context.signal = "HOLD"
                    context.decision = "HOLD"
                    db.log_signal(config.SYMBOL, "HOLD", close_price, {}, False, "Holding open trade position")
                    return

            if not active_trade:
                signal, filters, is_blocked, reason = self.strategy.evaluate_row(df, eval_idx)
                context.signal = signal
                context.decision = signal if not is_blocked else "HOLD"

                todays_pnl = db.get_todays_pnl(config.SYMBOL)
                daily_limit_hit = self.risk_manager.check_daily_loss_limit(todays_pnl, balance)

                if daily_limit_hit and signal in ["LONG", "SHORT"]:
                    logger.warning("Daily loss limit exceeded. Entry signal blocked.")
                    is_blocked = True
                    reason = f"Daily Loss Limit hit (Today PnL: {todays_pnl:.2f} USDT). Signal {signal} blocked."
                    signal = "HOLD"
                    context.signal = signal
                    context.decision = "HOLD"

                db.log_signal(config.SYMBOL, signal, close_price, filters, is_blocked, reason, {
                    "timeframe": config.TIMEFRAME,
                    "balance": balance,
                    "close_price": close_price,
                })

                if signal in ["LONG", "SHORT"]:
                    sl_price, tp_price = self.risk_manager.calculate_trade_levels(df, eval_idx, signal, close_price)
                    size = self.risk_manager.calculate_position_size(balance, close_price, sl_price)

                    if size > 0:
                        if signal == "LONG":
                            # Attempt real market BUY on Binance Testnet for LONG entries
                            try:
                                order = self.executor.market_buy(config.SYMBOL, size, close_price)
                                entry_price = float(order['average_price'])
                                filled = float(order['filled_amount'])
                                # Log the realized entry price and filled size
                                trade_id = db.log_trade_entry(config.SYMBOL, signal, entry_price, sl_price, tp_price, filled, metadata={"filters": filters, "reason": reason})
                                self.telegram.send_message(
                                    f"🟢 *NEW LONG SIGNAL - Real Execution*\n"
                                    f"• *Price*: {entry_price:.2f}\n"
                                    f"• *Executed Size*: {filled:.6f} BTC\n"
                                    f"• *Stop Loss*: {sl_price:.2f}\n"
                                    f"• *Take Profit*: {tp_price:.2f}\n"
                                    f"• *Risk*: {config.RISK_PCT_PER_TRADE * 100:.1f}%\n"
                                    f"• *Order ID*: {order.get('order_id') or 'N/A'}"
                                )
                            except Exception as exc:
                                stack = traceback.format_exc()
                                db.log_error(str(exc), stack, module="live_runner", function_name="process_cycle", retry_count=self.retry_count)
                                try:
                                    self.telegram.send_message(
                                        f"⚠️ *EXECUTION FAILED (Entry - LONG)*\n"
                                        f"• *Symbol*: {config.SYMBOL}\n"
                                        f"• *Reason*: {str(exc)}\n"
                                        f"• *Action*: Entry skipped and not logged."
                                    )
                                except Exception:
                                    logger.error("Failed to send Telegram alert for execution failure.")
                                # Do not log a phantom trade; abort this cycle
                                return
                        else:
                            # SHORT entries remain alert-only (cannot short on spot Testnet)
                            trade_id = db.log_trade_entry(config.SYMBOL, signal, close_price, sl_price, tp_price, size, metadata={"filters": filters, "reason": reason})
                            self.telegram.send_message(
                                f"🔴 *NEW SHORT SIGNAL - Alert Only (SHORT — spot can't short)*\n"
                                f"• *Price*: {close_price:.2f}\n"
                                f"• *EMA*: PASS\n"
                                f"• *MACD*: PASS\n"
                                f"• *Volume Profile*: PASS\n"
                                f"• *Stop Loss*: {sl_price:.2f}\n"
                                f"• *Take Profit*: {tp_price:.2f}\n"
                                f"• *Position Size*: {size:.6f} BTC\n"
                                f"• *Risk*: {config.RISK_PCT_PER_TRADE * 100:.1f}%"
                            )
                    else:
                        logger.warning("Strategy proposed entry, but risk manager calculated size of 0.0 BTC. Trade skipped.")
                else:
                    logger.info("Signal evaluated: HOLD. Reason/Details: %s", reason)
                    if is_blocked:
                        self.telegram.send_message(
                            f"🚫 *SIGNAL BLOCKED*\n"
                            f"• *Reason*: {reason}"
                        )

        except Exception as exc:
            status = "ERROR"
            error_msg = f"System Error in runner execution cycle: {exc}"
            logger.error(error_msg)
            stack_trace = traceback.format_exc()
            db.log_error(error_msg, stack_trace, module="live_runner", function_name="process_cycle", retry_count=self.retry_count)
            try:
                self.telegram.send_message(f"🚨 *CRITICAL ERROR*: {error_msg}")
            except Exception as tg_err:
                logger.error("Failed to send Telegram error alert: %s", tg_err)
        finally:
            try:
                self.retry_count = self.retry_count + 1 if status == "ERROR" else 0
                db.log_heartbeat(status, details={"signal": context.signal, "decision": context.decision, "balance": context.balance, "close_price": context.close_price})
                db.log_bot_status(status, exchange_status="CONNECTED", telegram_status="OK" if self.telegram.enabled else "DISABLED", database_status="OK", details={"signal": context.signal, "decision": context.decision})
                health = self.monitoring.collect_health_snapshot(balance=context.balance, equity=context.balance, current_position=0.0)
                db.log_daily_statistics({"total_trades": 0, "winning_trades": 0, "losing_trades": 0, "win_rate": 0.0, "daily_pnl": 0.0, "balance": context.balance, "equity": context.balance})
                if config.SEND_HEARTBEAT_MESSAGES and status != "ERROR":
                    self.telegram.send_message(
                        f"❤️ *BOT STATUS*\n"
                        f"• *Status*: {status}\n"
                        f"• *Exchange Connected*: {'YES' if self.testnet_fetcher.exchange else 'NO'}\n"
                        f"• *Current Price*: {context.close_price:.2f}\n"
                        f"• *Balance*: {context.balance:.2f} USDT\n"
                        f"• *Open Trades*: {'YES' if context.open_trade else 'NO'}\n"
                        f"• *Last Signal*: {context.signal}\n"
                        f"• *Database Status*: OK\n"
                        f"• *Internet Status*: {'CONNECTED' if health['internet_connected'] else 'OFFLINE'}\n"
                        f"• *Telegram Status*: {'OK' if self.telegram.enabled else 'DISABLED'}"
                    )
                logger.info("Logged heartbeat status: %s", status)
            except Exception as db_err:
                logger.error("Failed to log heartbeat in finally block: %s", db_err)

    def send_daily_summary(self):
        """
        Sends a daily status and execution summary via Telegram.
        """
        logger.info("Generating daily execution summary...")
        try:
            stats = db.get_daily_summary_stats()
            
            cycles_run = stats['cycles_run']
            errors_count = stats['errors_count']
            signals_fired = stats['signals_fired']
            
            # Format signals list
            signals_str = ""
            if signals_fired:
                signals_str = "\n".join([
                    f"• {s['timestamp'][:16]} - *{s['signal_type']}* at ${s['price']:.2f} (Reason: {s['reason'] or 'N/A'})"
                    for s in signals_fired
                ])
            else:
                signals_str = "None"
                
            summary_msg = (
                f"📊 *DAILY BOT SUMMARY (UTC)*\n"
                f"• *Status*: Active & Running\n"
                f"• *Timeframe*: {config.TIMEFRAME}\n"
                f"• *Total Cycles Run*: {cycles_run}\n"
                f"• *Errors Encountered*: {errors_count}\n"
                f"• *Signals Fired (excl. HOLD)*:\n{signals_str}"
            )
            
            self.telegram.send_message(summary_msg)
            logger.info("Daily summary sent successfully.")
        except Exception as e:
            logger.error(f"Failed to generate or send daily summary: {e}")

def pd_timestamp_to_str(ts_ms) -> str:
    """
    Converts milliseconds timestamp to ISO datetime string.
    """
    try:
        return datetime.utcfromtimestamp(ts_ms / 1000.0).isoformat()
    except:
        return str(ts_ms)

def get_active_trade() -> Optional[Dict[str, Any]]:
    """
    Helper to fetch the current active open trade from SQLite.
    """
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM trades_log WHERE status = 'OPEN' LIMIT 1")
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception as e:
        logger.error(f"Error fetching active trade from DB: {e}")
        return None

def main():
    logger.info("Initializing scheduled trading bot live runner...")
    runner = LiveRunner()
    
    # Startup Telegram notification
    startup_msg = (
        f"🚀 *{config.BOT_NAME} Started*\n"
        f"• *Exchange*: {config.EXCHANGE_NAME} {config.TRADING_MODE}\n"
        f"• *Timeframe*: {config.TIMEFRAME}\n"
        f"• *Check Interval*: {config.CHECK_INTERVAL_MINS} minute\n"
        f"• *Balance*: 10000 USDT\n"
        f"• *Status*: RUNNING"
    )
    try:
        runner.telegram.send_message(startup_msg)
    except Exception as e:
        logger.error(f"Failed to send startup Telegram alert: {e}")
    
    # Run once immediately on startup
    runner.process_cycle()

    # Schedule blocking loop
    scheduler = BlockingScheduler()
    scheduler.add_job(
        runner.process_cycle,
        'interval',
        minutes=config.CHECK_INTERVAL_MINS,
        id='market_check_job'
    )
    
    # Schedule daily summary job (runs every day at midnight UTC)
    scheduler.add_job(
        runner.send_daily_summary,
        'cron',
        hour=0,
        minute=0,
        timezone='UTC',
        id='daily_summary_job'
    )
    
    logger.info(f"Bot scheduled to check every {config.CHECK_INTERVAL_MINS} minutes.")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Scheduler shutdown successfully.")

if __name__ == "__main__":
    main()
