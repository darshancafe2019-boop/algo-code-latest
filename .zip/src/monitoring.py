import logging
import os
import platform
import shutil
import socket
import time
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple

from src import config
from src import db

logger = logging.getLogger("Monitoring")


class MonitoringService:
    """Collect runtime health information for the trading bot."""

    def __init__(self) -> None:
        self.started_at = datetime.utcnow()
        self.last_error_count = 0

    def get_uptime_seconds(self) -> float:
        return (datetime.utcnow() - self.started_at).total_seconds()

    def get_cpu_usage(self) -> Optional[float]:
        try:
            return os.getloadavg()[0] if hasattr(os, "getloadavg") else None
        except Exception:
            return None

    def get_ram_usage_mb(self) -> Optional[float]:
        try:
            return round(shutil.disk_usage(config.BASE_DIR).used / (1024 * 1024), 2)
        except Exception:
            return None

    def check_internet(self) -> Tuple[bool, Optional[float]]:
        try:
            start = time.perf_counter()
            socket.create_connection(("1.1.1.1", 443), timeout=3)
            latency_ms = round((time.perf_counter() - start) * 1000, 2)
            return True, latency_ms
        except OSError:
            return False, None

    def collect_health_snapshot(self, balance: Optional[float], equity: Optional[float], current_position: Optional[float]) -> Dict[str, object]:
        internet_connected, latency_ms = self.check_internet()
        cpu_percent = self.get_cpu_usage()
        ram_mb = self.get_ram_usage_mb()
        snapshot = {
            "cpu_percent": cpu_percent,
            "ram_mb": ram_mb,
            "internet_connected": internet_connected,
            "latency_ms": latency_ms,
            "balance": balance,
            "equity": equity,
            "current_position": current_position,
            "running_time_seconds": self.get_uptime_seconds(),
            "status": "RUNNING" if internet_connected else "DEGRADED",
        }
        db.log_system_health(
            cpu_percent=snapshot["cpu_percent"],
            ram_mb=snapshot["ram_mb"],
            internet_connected=bool(snapshot["internet_connected"]),
            latency_ms=snapshot["latency_ms"],
            balance=balance,
            equity=equity,
            current_position=current_position,
            running_time_seconds=snapshot["running_time_seconds"],
            status=snapshot["status"],
        )
        return snapshot
