import sys
import os
import subprocess
import time
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from src import config
from src.audit import log_audit_event, log_notification

logger = logging.getLogger("ProcessManager")

class BotProcessManager:
    """Manages the background execution of live_runner.py."""

    def __init__(self):
        self.process: Optional[subprocess.Popen] = None
        self.start_time: Optional[datetime] = None
        self.is_paused: bool = False
        self.status_state: str = "STOPPED"
        self.last_error: str = ""

    def start_bot(self) -> Dict[str, Any]:
        """Start the live runner process if not running."""
        if self.is_running():
            return {"status": "error", "message": "Bot is already running."}

        # Check if kill switch active
        if config.KILL_SWITCH_FILE.exists():
            return {"status": "error", "message": "Kill switch is active. Deactivate kill switch first."}

        try:
            python_executable = sys.executable
            runner_path = config.BASE_DIR / "src" / "live_runner.py"
            
            # Spawn process
            self.process = subprocess.Popen(
                [python_executable, str(runner_path)],
                cwd=str(config.BASE_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.start_time = datetime.now(timezone.utc)
            self.is_paused = False
            self.status_state = "RUNNING"
            self.last_error = ""

            log_audit_event(action="BOT_START", user="Trader", details={"pid": self.process.pid})
            log_notification("INFO", "Bot Control", f"Live Trading Bot started (PID {self.process.pid}).")
            return {"status": "success", "message": f"Bot started successfully (PID: {self.process.pid}).", "pid": self.process.pid}
        except Exception as e:
            self.status_state = "ERROR"
            self.last_error = str(e)
            logger.error(f"Failed to start bot process: {e}")
            log_notification("ERROR", "Bot Control", f"Failed to start bot: {e}")
            return {"status": "error", "message": str(e)}

    def stop_bot(self) -> Dict[str, Any]:
        """Stop the live runner process."""
        if not self.is_running() and self.process is None:
            self.status_state = "STOPPED"
            return {"status": "success", "message": "Bot is already stopped."}

        try:
            if self.process:
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                self.process = None

            self.status_state = "STOPPED"
            self.is_paused = False
            self.start_time = None
            log_audit_event(action="BOT_STOP", user="Trader")
            log_notification("WARNING", "Bot Control", "Live Trading Bot stopped.")
            return {"status": "success", "message": "Bot stopped successfully."}
        except Exception as e:
            logger.error(f"Error stopping bot process: {e}")
            return {"status": "error", "message": str(e)}

    def pause_bot(self) -> Dict[str, Any]:
        """Pause trading bot evaluation cycles."""
        if not self.is_running():
            return {"status": "error", "message": "Bot is not running."}

        self.is_paused = True
        self.status_state = "PAUSED"
        log_audit_event(action="BOT_PAUSE", user="Trader")
        log_notification("WARNING", "Bot Control", "Bot trading execution paused.")
        return {"status": "success", "message": "Bot execution paused."}

    def resume_bot(self) -> Dict[str, Any]:
        """Resume trading bot execution cycles."""
        if self.status_state != "PAUSED":
            return {"status": "error", "message": "Bot is not paused."}

        self.is_paused = False
        self.status_state = "RUNNING"
        log_audit_event(action="BOT_RESUME", user="Trader")
        log_notification("INFO", "Bot Control", "Bot trading execution resumed.")
        return {"status": "success", "message": "Bot execution resumed."}

    def trigger_kill_switch(self) -> Dict[str, Any]:
        """Activate Kill Switch: create flag file and terminate bot process."""
        try:
            config.KILL_SWITCH_FILE.touch(exist_ok=True)
            self.stop_bot()
            self.status_state = "STOPPED"
            log_audit_event(action="KILL_SWITCH_ACTIVATED", user="Trader", details={"reason": "Manual Kill Switch Triggered"})
            log_notification("ERROR", "Kill Switch", "KILL SWITCH ACTIVATED! Bot stopped and position exit signal sent.")
            return {"status": "success", "message": "KILL SWITCH ACTIVATED. All trading stopped."}
        except Exception as e:
            logger.error(f"Failed to activate kill switch: {e}")
            return {"status": "error", "message": str(e)}

    def deactivate_kill_switch(self) -> Dict[str, Any]:
        """Deactivate Kill Switch flag."""
        try:
            if config.KILL_SWITCH_FILE.exists():
                config.KILL_SWITCH_FILE.unlink()
            log_audit_event(action="KILL_SWITCH_DEACTIVATED", user="Trader")
            log_notification("INFO", "Kill Switch", "Kill switch deactivated.")
            return {"status": "success", "message": "Kill switch deactivated."}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def is_running(self) -> bool:
        """Check if process is active."""
        if self.process is not None:
            poll = self.process.poll()
            if poll is None:
                return True
            else:
                self.process = None
                if self.status_state == "RUNNING":
                    self.status_state = "STOPPED"
        return False

    def get_status(self) -> Dict[str, Any]:
        """Return status payload."""
        running = self.is_running()
        uptime_seconds = 0
        uptime_formatted = "0m 0s"

        if running and self.start_time:
            delta = datetime.now(timezone.utc) - self.start_time
            uptime_seconds = int(delta.total_seconds())
            hours, remainder = divmod(uptime_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            if hours > 0:
                uptime_formatted = f"{hours}h {minutes}m {seconds}s"
            else:
                uptime_formatted = f"{minutes}m {seconds}s"

        kill_switch_active = config.KILL_SWITCH_FILE.exists()

        state = self.status_state
        if kill_switch_active:
            state = "KILL_SWITCH_ACTIVE"
        elif not running and state not in ["PAUSED", "ERROR"]:
            state = "STOPPED"

        return {
            "status": state,
            "is_running": running,
            "is_paused": self.is_paused,
            "kill_switch_active": kill_switch_active,
            "uptime_seconds": uptime_seconds,
            "uptime_formatted": uptime_formatted,
            "pid": self.process.pid if self.process else None,
            "last_error": self.last_error
        }

bot_manager = BotProcessManager()
