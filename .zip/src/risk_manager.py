import os
import logging
from pathlib import Path
from typing import Tuple
import pandas as pd
from src import config

logger = logging.getLogger("RiskManager")

class RiskManager:
    """
    Manages risk parameters, calculates position sizing, sets stop-loss and take-profit levels,
    and enforces trading limits (max concurrent positions, daily loss limit, and kill switch).
    """

    def __init__(self, kill_switch_file: Path = config.KILL_SWITCH_FILE):
        self.kill_switch_file = kill_switch_file

    def is_kill_switch_active(self) -> bool:
        """
        Checks if the kill switch file exists in the workspace.
        
        Returns:
            bool: True if the file exists (kill switch is active), False otherwise.
        """
        if self.kill_switch_file.exists():
            logger.warning(f"Kill switch active! Found flag file: {self.kill_switch_file}")
            return True
        return False

    def calculate_swing_levels(self, df: pd.DataFrame, idx: int, lookback: int) -> Tuple[float, float]:
        """
        Helper to calculate swing low and swing high prices over a lookback window.
        
        Args:
            df (pd.DataFrame): Dataframe with 'high' and 'low' columns.
            idx (int): Current row index.
            lookback (int): Number of previous candles to scan.
            
        Returns:
            Tuple[float, float]: (swing_low, swing_high)
        """
        start_idx = max(0, idx - lookback + 1)
        window = df.iloc[start_idx:idx + 1]
        swing_low = float(window['low'].min())
        swing_high = float(window['high'].max())
        return swing_low, swing_high

    def calculate_trade_levels(
        self,
        df: pd.DataFrame,
        idx: int,
        direction: str,
        entry_price: float
    ) -> Tuple[float, float]:
        """
        Calculates Stop-Loss (SL) and Take-Profit (TP) prices according to configuration rules.
        
        Args:
            df (pd.DataFrame): Dataframe with candles and volume profile indicators.
            idx (int): Current row index.
            direction (str): Trade direction ("LONG" or "SHORT").
            entry_price (float): Executed/proposed entry price.
            
        Returns:
            Tuple[float, float]: (stop_loss_price, take_profit_price)
        """
        row = df.iloc[idx]
        val = float(row['val'])
        vah = float(row['vah'])
        
        # Calculate swing low/high
        swing_low, swing_high = self.calculate_swing_levels(df, idx, config.SWING_LOOKBACK_CANDLES)

        if direction == "LONG":
            # --- STOP LOSS ---
            # VAL stop-loss: just below VAL (we can add a tiny 0.1% buffer or use VAL itself)
            val_sl = val * 0.999  # 0.1% below VAL
            
            # Swing low stop-loss: just below swing low
            swing_sl = swing_low * 0.999
            
            # Choose Stop Loss based on method
            if config.STOP_LOSS_METHOD == "fixed_pct":
                stop_loss = entry_price * (1.0 - config.FIXED_STOP_LOSS_PCT)
            elif config.STOP_LOSS_METHOD == "tighter":
                # Tighter stop means closer to entry (highest stop-loss price)
                # But must be below entry price
                valid_sls = [sl for sl in [val_sl, swing_sl] if sl < entry_price]
                stop_loss = max(valid_sls) if valid_sls else entry_price * 0.98  # fallback 2%
            elif config.STOP_LOSS_METHOD == "val_vah":
                stop_loss = val_sl if val_sl < entry_price else entry_price * 0.98
            else:  # swing
                stop_loss = swing_sl if swing_sl < entry_price else entry_price * 0.98

            # --- TAKE PROFIT ---
            sl_distance = entry_price - stop_loss
            tp_rr = entry_price + (config.FIXED_RISK_REWARD_RATIO * sl_distance) if config.TAKE_PROFIT_METHOD == "fixed_rr" else entry_price + (2.0 * sl_distance)
            
            # Next resistance level (VAH)
            # If entry price is below VAH, VAH is our resistance. Otherwise VAH is not a valid target.
            vah_tp = VAH = vah
            
            if config.TAKE_PROFIT_METHOD == "conservative":
                # More conservative means closer to entry (lowest take-profit price)
                if VAH > entry_price:
                    take_profit = min(tp_rr, VAH)
                else:
                    take_profit = tp_rr
            else:
                take_profit = tp_rr

        elif direction == "SHORT":
            # --- STOP LOSS ---
            # VAH stop-loss: just above VAH
            vah_sl = vah * 1.001  # 0.1% above VAH
            
            # Swing high stop-loss: just above swing high
            swing_sl = swing_high * 1.001
            
            if config.STOP_LOSS_METHOD == "fixed_pct":
                stop_loss = entry_price * (1.0 + config.FIXED_STOP_LOSS_PCT)
            elif config.STOP_LOSS_METHOD == "tighter":
                # Tighter stop means closer to entry (lowest stop-loss price)
                # But must be above entry price
                valid_sls = [sl for sl in [vah_sl, swing_sl] if sl > entry_price]
                stop_loss = min(valid_sls) if valid_sls else entry_price * 1.02  # fallback 2%
            elif config.STOP_LOSS_METHOD == "val_vah":
                stop_loss = vah_sl if vah_sl > entry_price else entry_price * 1.02
            else:  # swing
                stop_loss = swing_sl if swing_sl > entry_price else entry_price * 1.02

            # --- TAKE PROFIT ---
            sl_distance = stop_loss - entry_price
            tp_rr = entry_price - (config.FIXED_RISK_REWARD_RATIO * sl_distance) if config.TAKE_PROFIT_METHOD == "fixed_rr" else entry_price - (2.0 * sl_distance)
            
            # Next support level (VAL)
            # If entry price is above VAL, VAL is our support. Otherwise VAL is not a valid target.
            val_tp = VAL = val
            
            if config.TAKE_PROFIT_METHOD == "conservative":
                # More conservative means closer to entry (highest take-profit price)
                if VAL < entry_price:
                    take_profit = max(tp_rr, VAL)
                else:
                    take_profit = tp_rr
            else:
                take_profit = tp_rr
        else:
            raise ValueError(f"Invalid direction: {direction}")

        # Final safety sanity check
        if stop_loss == entry_price:
            stop_loss = entry_price * 0.98 if direction == "LONG" else entry_price * 1.02
            
        return round(stop_loss, 2), round(take_profit, 2)

    def calculate_position_size(
        self,
        account_balance: float,
        entry_price: float,
        stop_loss_price: float
    ) -> float:
        """
        Calculates the position size in BTC based on the account balance,
        risk percentage, and stop-loss distance.
        
        Args:
            account_balance (float): Total available balance (USDT).
            entry_price (float): Entry price of BTC.
            stop_loss_price (float): Stop-loss price.
            
        Returns:
            float: Position size in BTC. Capped to available cash.
        """
        sl_distance = abs(entry_price - stop_loss_price)
        if sl_distance <= 1e-4:
            logger.warning("Stop loss distance is zero or near-zero. Position size calculation aborted.")
            return 0.0

        # Amount we are willing to lose in USDT
        risk_amount_usdt = account_balance * config.RISK_PCT_PER_TRADE
        
        # Position size in BTC
        position_size_btc = risk_amount_usdt / sl_distance
        
        # Spot Trading Constraint: cannot buy more than we have cash for
        max_possible_btc = account_balance / entry_price
        
        if position_size_btc > max_possible_btc:
            logger.info(f"Capping position size {position_size_btc:.6f} BTC to available cash equivalent {max_possible_btc:.6f} BTC.")
            position_size_btc = max_possible_btc

        return round(position_size_btc, 6)

    def check_daily_loss_limit(self, todays_pnl_usdt: float, account_balance: float) -> bool:
        """
        Enforces the daily drawdown limit.
        
        Args:
            todays_pnl_usdt (float): Aggregated PnL of all trades closed today.
            account_balance (float): Current account balance.
            
        Returns:
            bool: True if daily loss limit is hit (trading should stop), False otherwise.
        """
        if account_balance <= 0:
            return True
            
        # Drawdown as negative fraction, e.g. -0.05 for -5%
        drawdown_pct = todays_pnl_usdt / account_balance
        if drawdown_pct <= config.DAILY_LOSS_LIMIT_PCT:
            logger.warning(f"Daily loss limit hit! Current daily drawdown: {drawdown_pct*100:.2f}% (Limit: {config.DAILY_LOSS_LIMIT_PCT*100:.2f}%)")
            return True
        return False
