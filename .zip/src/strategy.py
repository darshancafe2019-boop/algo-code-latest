import logging
from typing import Tuple, Dict, Any, Optional

import numpy as np
import pandas as pd

from src import config
from src.data_fetcher import DataFetcher
from src.indicators import calculate_rsi

logger = logging.getLogger("Strategy")


def _format_reason(reason_parts: list[str]) -> str:
    return " | ".join(reason_parts) if reason_parts else ""


class Strategy:
    
    """
    Implements the trading strategy logic combining four filters:
    1. Trend Bias (EMA 200)
    2. Timing Crossover Trigger (EMA 9 crossing EMA 20)
    3. Momentum Confirmation (MACD Line relative to 0)
    4. Location Filter (Volume Profile VAH/VAL boundaries with buffer)

    Optional confirmation filters can be enabled via config:
    - USE_EMA9_FILTER: close bias relative to EMA9
    - USE_RSI_FILTER: 5m RSI confirmation (>60 long, <40 short)
    - USE_DAILY_BIAS_FILTER: current daily open bias
    """

    def __init__(self, allow_shorts: bool = config.ALLOW_SHORTS):
        self.allow_shorts = allow_shorts
        self._data_fetcher: Optional[DataFetcher] = None

    @property
    def data_fetcher(self) -> DataFetcher:
        if self._data_fetcher is None:
            self._data_fetcher = DataFetcher(use_testnet=False)
        return self._data_fetcher

    def _fetch_5m_rsi_value(self) -> float:
        candles = self.data_fetcher.fetch_live_ohlcv(config.SYMBOL, config.RSI_TIMEFRAME, limit=max(100, config.RSI_LENGTH * 4))
        if candles.empty or len(candles) < config.RSI_LENGTH + 1:
            raise ValueError("Insufficient 5m candles to calculate RSI")

        candles = calculate_rsi(candles, length=config.RSI_LENGTH)
        last_rsi = float(candles.iloc[-2].get('rsi', np.nan))
        if pd.isna(last_rsi):
            raise ValueError("RSI calculation returned NaN")
        return last_rsi

    def _fetch_daily_open_value(self) -> float:
        candles = self.data_fetcher.fetch_live_ohlcv(config.SYMBOL, "1d", limit=3)
        if candles.empty or len(candles) < 1:
            raise ValueError("Insufficient daily candles to calculate daily bias")

        daily_open = float(candles.iloc[-1]['open'])
        return daily_open

    def check_ema9_bias(self, close_price: float, ema_9: float, direction: str) -> Tuple[bool, float]:
        if pd.isna(ema_9):
            return False, float('nan')
        if direction == "LONG":
            return close_price > ema_9, ema_9
        return close_price < ema_9, ema_9

    def check_rsi_filter(self, direction: str, extra_data: Optional[Dict[str, Any]] = None) -> Tuple[bool, float]:
        rsi_value = None
        if extra_data and "rsi_5m" in extra_data:
            rsi_value = extra_data["rsi_5m"]

        if rsi_value is None:
            rsi_value = self._fetch_5m_rsi_value()

        if pd.isna(rsi_value):
            return False, float('nan')

        if direction == "LONG":
            return rsi_value > 60.0, rsi_value
        return rsi_value < 40.0, rsi_value

    def check_daily_bias(self, close_price: float, direction: str, extra_data: Optional[Dict[str, Any]] = None) -> Tuple[bool, float]:
        daily_open = None
        if extra_data and "daily_open" in extra_data:
            daily_open = extra_data["daily_open"]

        if daily_open is None:
            daily_open = self._fetch_daily_open_value()

        if pd.isna(daily_open):
            return False, float('nan')

        if direction == "LONG":
            return close_price > daily_open, daily_open
        return close_price < daily_open, daily_open

    def evaluate_row(self, df: pd.DataFrame, idx: int, extra_data: Optional[Dict[str, Any]] = None) -> Tuple[str, Dict[str, bool], bool, str]:
        """
        Evaluates the strategy rules at a specific row index in the dataframe.

        Args:
            df (pd.DataFrame): Dataframe with OHLCV and all indicators.
            idx (int): Row index to evaluate. Must be >= 1 to allow crossover checks.
            extra_data (dict, optional): Precomputed values for optional filters, such as rsi_5m and daily_open.

        Returns:
            Tuple[str, Dict[str, bool], bool, str]
        """
        if idx < 1:
            return "HOLD", {}, False, "Insufficient history for crossover check"

        row = df.iloc[idx]
        prev_row = df.iloc[idx - 1]

        close_val = float(row['close'])
        ema_9 = float(row.get('ema_9', np.nan))
        ema_20 = float(row.get('ema_20', np.nan))
        ema_50 = float(row.get('ema_50', np.nan))
        ema_200 = float(row.get('ema_200', np.nan))
        macd_line = float(row.get('macd_line', np.nan))
        macd_signal = float(row.get('macd_signal', np.nan))
        macd_hist = float(row.get('macd_hist', np.nan))

        poc = row['poc']
        val = row['val']
        vah = row['vah']

        prev_ema_9 = float(prev_row.get('ema_9', np.nan))
        prev_ema_20 = float(prev_row.get('ema_20', np.nan))

        if (
            pd.isna(ema_9)
            or pd.isna(ema_20)
            or pd.isna(ema_200)
            or pd.isna(macd_line)
            or pd.isna(prev_ema_9)
            or pd.isna(prev_ema_20)
            or pd.isna(val)
            or pd.isna(vah)
        ):
            return "HOLD", {}, False, "Indicators not fully calculated"

        long_cross = (prev_ema_9 <= prev_ema_20) and (ema_9 > ema_20)
        short_cross = (prev_ema_9 >= prev_ema_20) and (ema_9 < ema_20)

        filter_statuses = {
            "trend": False,
            "trigger": False,
            "momentum": False,
            "location": False,
            "ema9_bias": not config.USE_EMA9_FILTER,
            "rsi": not config.USE_RSI_FILTER,
            "daily_bias": not config.USE_DAILY_BIAS_FILTER,
        }

        if not long_cross and not short_cross:
            logger.debug(
                "No EMA crossover | close=%.2f ema_9=%.2f ema_20=%.2f ema_50=%.2f ema_200=%.2f macd=%.4f signal=%.4f hist=%.4f",
                close_val, ema_9, ema_20, ema_50, ema_200, macd_line, macd_signal, macd_hist,
            )
            return "HOLD", filter_statuses, False, ""

        filter_statuses["trigger"] = True

        decision_context = {
            "close": close_val,
            "ema_9": ema_9,
            "ema_20": ema_20,
            "ema_50": ema_50,
            "ema_200": ema_200,
            "macd_line": macd_line,
            "macd_signal": macd_signal,
            "macd_hist": macd_hist,
            "poc": poc,
            "val": val,
            "vah": vah,
        }

        def _evaluate_optional_filters(direction: str) -> Tuple[bool, list[str]]:
            reasons = []
            if config.USE_EMA9_FILTER:
                ema9_passed, ema9_value = self.check_ema9_bias(close_val, ema_9, direction)
                filter_statuses["ema9_bias"] = ema9_passed
                decision_context["ema9_value"] = ema9_value
                if not ema9_passed:
                    reasons.append(f"EMA9 bias blocked (Close {close_val:.2f} vs EMA9 {ema9_value:.2f})")

            if config.USE_RSI_FILTER:
                try:
                    rsi_passed, rsi_value = self.check_rsi_filter(direction, extra_data=extra_data)
                    filter_statuses["rsi"] = rsi_passed
                    decision_context["rsi_5m"] = rsi_value
                    if not rsi_passed:
                        reasons.append(f"RSI blocked (RSI {rsi_value:.2f} not in required range)")
                except Exception as exc:
                    filter_statuses["rsi"] = False
                    reasons.append(f"RSI fetch blocked ({exc})")

            if config.USE_DAILY_BIAS_FILTER:
                try:
                    daily_passed, daily_open = self.check_daily_bias(close_val, direction, extra_data=extra_data)
                    filter_statuses["daily_bias"] = daily_passed
                    decision_context["daily_open"] = daily_open
                    if not daily_passed:
                        reasons.append(f"Daily bias blocked (Close {close_val:.2f} vs daily open {daily_open:.2f})")
                except Exception as exc:
                    filter_statuses["daily_bias"] = False
                    reasons.append(f"Daily data fetch blocked ({exc})")

            return (all(filter_statuses[k] for k in ["ema9_bias", "rsi", "daily_bias"]), reasons)

        def _finalize(direction: str, base_passed: bool, base_reasons: list[str]) -> Tuple[str, Dict[str, bool], bool, str]:
            if base_passed:
                optional_passed, optional_reasons = _evaluate_optional_filters(direction)
                if optional_passed:
                    logger.info(
                        "%s signal accepted | close=%.2f ema_9=%.2f ema_20=%.2f ema_50=%.2f ema_200=%.2f macd=%.4f val=%.2f vah=%.2f",
                        direction, close_val, ema_9, ema_20, ema_50, ema_200, macd_line, val, vah,
                    )
                    return direction, filter_statuses, False, ""
                reasons = base_reasons + optional_reasons
            else:
                reasons = base_reasons
                _evaluate_optional_filters(direction)

            block_msg = _format_reason(reasons)
            logger.info("%s signal blocked | %s | context=%s", direction, block_msg, decision_context)
            return "HOLD", filter_statuses, True, f"{direction} setup blocked: {block_msg}"

        if long_cross:
            trend_passed = close_val > ema_200
            filter_statuses["trend"] = trend_passed
            momentum_passed = macd_line > 0
            filter_statuses["momentum"] = momentum_passed
            lower_bound = float(val) * (1.0 - config.VP_BUFFER_PCT)
            upper_bound = float(vah) * (1.0 + config.VP_BUFFER_PCT)
            location_passed = (close_val >= lower_bound) and (close_val <= upper_bound)
            filter_statuses["location"] = location_passed

            reasons = []
            if not trend_passed:
                reasons.append(f"Trend blocked (Close {close_val:.2f} <= EMA200 {ema_200:.2f})")
            if not momentum_passed:
                reasons.append(f"Momentum blocked (MACD {macd_line:.4f} <= 0)")
            if not location_passed:
                reasons.append(
                    f"Location blocked (Close {close_val:.2f} outside Value Area [{lower_bound:.2f} - {upper_bound:.2f}], VAL={val:.2f}, VAH={vah:.2f})"
                )

            return _finalize("LONG", trend_passed and momentum_passed and location_passed, reasons)

        if short_cross:
            if not self.allow_shorts:
                logger.info("SHORT signal blocked because ALLOW_SHORTS is disabled")
                return "HOLD", filter_statuses, True, "SHORT setup blocked: ALLOW_SHORTS is False"

            trend_passed = close_val < ema_200
            filter_statuses["trend"] = trend_passed
            momentum_passed = macd_line < 0
            filter_statuses["momentum"] = momentum_passed
            lower_bound = float(val) * (1.0 - config.VP_BUFFER_PCT)
            upper_bound = float(vah) * (1.0 + config.VP_BUFFER_PCT)
            location_passed = (close_val >= lower_bound) and (close_val <= upper_bound)
            filter_statuses["location"] = location_passed

            reasons = []
            if not trend_passed:
                reasons.append(f"Trend blocked (Close {close_val:.2f} >= EMA200 {ema_200:.2f})")
            if not momentum_passed:
                reasons.append(f"Momentum blocked (MACD {macd_line:.4f} >= 0)")
            if not location_passed:
                reasons.append(
                    f"Location blocked (Close {close_val:.2f} outside Value Area [{lower_bound:.2f} - {upper_bound:.2f}], VAL={val:.2f}, VAH={vah:.2f})"
                )

            return _finalize("SHORT", trend_passed and momentum_passed and location_passed, reasons)

        return "HOLD", filter_statuses, False, ""
