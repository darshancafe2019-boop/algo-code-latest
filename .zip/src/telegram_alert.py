import logging
from typing import Optional
import requests
from src import config, db

logger = logging.getLogger("TelegramAlert")


class TelegramAlert:
    """Send formatted notifications to Telegram while logging delivery attempts."""

    def __init__(self, token: Optional[str] = None, chat_id: Optional[str] = None) -> None:
        self.token = token or config.TELEGRAM_BOT_TOKEN
        self.chat_id = chat_id or config.TELEGRAM_CHAT_ID
        self.enabled = bool(self.token and self.chat_id)
        if not self.enabled:
            logger.warning("Telegram alerts are DISABLED. Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in your .env file.")

    def send_message(self, text: str) -> bool:
        """Send a synchronous text message to the configured Telegram chat."""
        if not self.enabled:
            logger.info("Skipping Telegram notification (disabled): %s", text)
            return False

        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": text, "parse_mode": "Markdown"}

        try:
            logger.info("Sending Telegram alert...")
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                db.log_telegram_event(success=True, message=text)
                logger.info("Telegram alert sent successfully.")
                return True
            error_text = response.text
            logger.error("Failed to send Telegram alert. HTTP Status: %s. Response: %s", response.status_code, error_text)
            db.log_telegram_event(success=False, message=text, error=error_text)
            return False
        except Exception as exc:
            logger.error("Failed to send Telegram alert due to connection error: %s", exc)
            db.log_telegram_event(success=False, message=text, error=str(exc))
            return False
