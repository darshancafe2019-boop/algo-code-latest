/**
 * BTC ALGO TRADING PLATFORM DASHBOARD JAVASCRIPT
 * Handles live polling, canvas charting, bot controls, analytics, backtests, and theme switching.
 */

let activeTimeframe = "5m";
let currentCandleData = [];
let pendingModalAction = null;

// Initialization
document.addEventListener("DOMContentLoaded", () => {
    initApp();
    startPolling();
});

function initApp() {
    fetchTicker();
    fetchCandles();
    fetchOrderBook();
    fetchBotStatus();
    fetchStrategyConfig();
    fetchAnalytics();
    fetchTrades();
    fetchNotifications();
    fetchAuditLogs();
    fetchLogs();
}

// Polling interval
function startPolling() {
    setInterval(fetchTicker, 3000);
    setInterval(fetchOrderBook, 4000);
    setInterval(fetchBotStatus, 5000);
    setInterval(fetchCandles, 10000);
    setInterval(fetchAnalytics, 15000);
    setInterval(fetchNotifications, 10000);
}

// Tab navigation
function switchTab(tabId) {
    document.querySelectorAll(".nav-item").forEach(btn => {
        btn.classList.toggle("active", btn.getAttribute("data-tab") === tabId);
    });

    document.querySelectorAll(".tab-content").forEach(tab => {
        tab.classList.toggle("active", tab.id === `tab-${tabId}`);
    });

    if (tabId === "charting") {
        renderTradingChart(currentCandleData);
    } else if (tabId === "analytics") {
        fetchAnalytics();
    } else if (tabId === "logs") {
        fetchLogs();
    }
}

// Timeframe switcher
function setTimeframe(tf) {
    activeTimeframe = tf;
    document.querySelectorAll(".tf-btn").forEach(btn => {
        btn.classList.toggle("active", btn.textContent.trim().toLowerCase() === tf.toLowerCase());
    });
    fetchCandles();
}

// --------------------------------------------------------------------------
// SECTION 1: TICKER, CANDLES & ORDERBOOK
// --------------------------------------------------------------------------
async function fetchTicker() {
    try {
        const res = await fetch("/api/ticker");
        const json = await res.json();
        if (json.status === "success" || json.status === "warning") {
            const data = json.data;
            document.getElementById("top-price").textContent = `$${data.last.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            
            const changeEl = document.getElementById("top-change");
            const isPos = data.change_pct >= 0;
            changeEl.textContent = `${isPos ? '+' : ''}${data.change_pct.toFixed(2)}%`;
            changeEl.className = `ticker-value ${isPos ? 'text-success' : 'text-danger'}`;

            document.getElementById("top-high").textContent = `$${data.high.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById("top-low").textContent = `$${data.low.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            document.getElementById("top-vol").textContent = `${data.volume.toFixed(2)} BTC`;
            document.getElementById("latency-text").textContent = `${data.latency_ms} ms`;
        }
    } catch (e) {
        console.error("Ticker fetch error:", e);
    }
}

async function fetchCandles() {
    try {
        const res = await fetch(`/api/candles?timeframe=${activeTimeframe}&limit=120`);
        const json = await res.json();
        if (json.status === "success") {
            currentCandleData = json;
            renderTradingChart(json);
        }
    } catch (e) {
        console.error("Candles fetch error:", e);
    }
}

async function fetchOrderBook() {
    try {
        const res = await fetch("/api/orderbook");
        const json = await res.json();
        if (json.bids && json.asks) {
            renderOrderBook(json.bids, json.asks);
        }
    } catch (e) {
        console.error("Orderbook fetch error:", e);
    }
}

function renderOrderBook(bids, asks) {
    const asksContainer = document.getElementById("ob-asks-list");
    const bidsContainer = document.getElementById("ob-bids-list");

    asksContainer.innerHTML = asks.slice(0, 7).reverse().map(a => `
        <div class="ob-row">
            <span>${a.price.toFixed(2)}</span>
            <span>${a.amount.toFixed(4)}</span>
        </div>
    `).join('');

    bidsContainer.innerHTML = bids.slice(0, 7).map(b => `
        <div class="ob-row">
            <span>${b.price.toFixed(2)}</span>
            <span>${b.amount.toFixed(4)}</span>
        </div>
    `).join('');

    if (asks.length > 0 && bids.length > 0) {
        const spread = asks[0].price - bids[0].price;
        document.getElementById("ob-spread").textContent = `Spread: $${spread.toFixed(2)}`;
    }
}

// HTML5 Canvas Candlestick & Indicator Renderer
function renderTradingChart(data) {
    const canvas = document.getElementById("trading-chart-canvas");
    if (!canvas || !data || !data.candles || data.candles.length === 0) return;

    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Clear Background
    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--bg-card') || "#141822";
    ctx.fillRect(0, 0, width, height);

    const candles = data.candles;
    const count = candles.length;
    const paddingRight = 60;
    const chartWidth = width - paddingRight;
    const candleWidth = Math.max(3, (chartWidth / count) - 2);

    // Min & Max Price
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    candles.forEach(c => {
        if (c.low < minPrice) minPrice = c.low;
        if (c.high > maxPrice) maxPrice = c.high;
    });

    const priceMargin = (maxPrice - minPrice) * 0.05 || 100;
    minPrice -= priceMargin;
    maxPrice += priceMargin;

    function getY(price) {
        return height - ((price - minPrice) / (maxPrice - minPrice)) * (height - 40) - 20;
    }

    // Grid lines
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
        const price = minPrice + (i / 4) * (maxPrice - minPrice);
        const y = getY(price);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();

        ctx.fillStyle = "#5a6875";
        ctx.font = "10px sans-serif";
        ctx.fillText(`$${price.toFixed(0)}`, width - 55, y + 3);
    }

    // Volume Profile POC / VAL / VAH Overlays
    if (data.volume_profile) {
        const vp = data.volume_profile;
        ctx.setLineDash([4, 4]);
        
        // POC
        ctx.strokeStyle = "#f1c40f";
        const pocY = getY(vp.poc);
        ctx.beginPath(); ctx.moveTo(0, pocY); ctx.lineTo(width, pocY); ctx.stroke();

        // VAL / VAH
        ctx.strokeStyle = "#9b59b6";
        const valY = getY(vp.val);
        const vahY = getY(vp.vah);
        ctx.beginPath(); ctx.moveTo(0, valY); ctx.lineTo(width, valY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, vahY); ctx.lineTo(width, vahY); ctx.stroke();
        ctx.setLineDash([]);
    }

    // Draw EMAs
    function drawEMALine(prop, color) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        let started = false;
        candles.forEach((c, idx) => {
            const val = c[prop];
            if (val !== null && val !== undefined) {
                const x = idx * (chartWidth / count) + candleWidth / 2;
                const y = getY(val);
                if (!started) { ctx.moveTo(x, y); started = true; }
                else { ctx.lineTo(x, y); }
            }
        });
        ctx.stroke();
    }

    drawEMALine("ema_9", "#00b4d8");
    drawEMALine("ema_20", "#f7931a");
    drawEMALine("ema_50", "#9b59b6");
    drawEMALine("ema_200", "#e74c3c");

    // Draw Candlesticks
    candles.forEach((c, idx) => {
        const x = idx * (chartWidth / count);
        const openY = getY(c.open);
        const closeY = getY(c.close);
        const highY = getY(c.high);
        const lowY = getY(c.low);

        const isBull = c.close >= c.open;
        const color = isBull ? "#00c076" : "#ff3b69";

        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        // Wick
        ctx.beginPath();
        ctx.moveTo(x + candleWidth / 2, highY);
        ctx.lineTo(x + candleWidth / 2, lowY);
        ctx.stroke();

        // Body
        ctx.fillStyle = color;
        const bodyY = Math.min(openY, closeY);
        const bodyH = Math.max(2, Math.abs(closeY - openY));
        ctx.fillRect(x, bodyY, candleWidth, bodyH);
    });
}

// --------------------------------------------------------------------------
// SECTION 2: BOT CONTROL & STRATEGY
// --------------------------------------------------------------------------
async function fetchBotStatus() {
    try {
        const res = await fetch("/api/status");
        const json = await res.json();
        if (json.bot) {
            const b = json.bot;
            const badge = document.getElementById("bot-status-badge");
            badge.textContent = b.status;
            badge.className = `status-badge status-${b.status.toLowerCase()}`;

            document.getElementById("ctrl-bot-status").textContent = b.status;
            document.getElementById("ctrl-bot-uptime").textContent = b.uptime_formatted;
            document.getElementById("sidebar-uptime").textContent = b.uptime_formatted;

            if (json.open_trade) {
                document.getElementById("ctrl-open-trade").textContent = `${json.open_trade.direction} @ $${json.open_trade.entry_price}`;
            } else {
                document.getElementById("ctrl-open-trade").textContent = "NONE";
            }
        }
    } catch (e) {
        console.error("Status fetch error:", e);
    }
}

async function controlBot(action) {
    try {
        const res = await fetch("/api/bot/control", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action})
        });
        const json = await res.json();
        alert(json.message);
        fetchBotStatus();
    } catch (e) {
        alert("Failed to execute bot control action: " + e);
    }
}

function promptKillSwitch() {
    pendingModalAction = "KILL_SWITCH";
    document.getElementById("modal-msg").textContent = "CRITICAL: Activating the Kill Switch will immediately cancel all active orders, terminate trading, and set the system into emergency lock state.";
    document.getElementById("modal-2fa-group").style.display = "block";
    document.getElementById("confirm-modal").style.display = "flex";
}

function closeModal() {
    document.getElementById("confirm-modal").style.display = "none";
    pendingModalAction = null;
}

async function executeModalAction() {
    if (pendingModalAction === "KILL_SWITCH") {
        const token = document.getElementById("modal-token-input").value.trim();
        try {
            const res = await fetch("/api/bot/control", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({action: "KILL_SWITCH", confirmation_token: token})
            });
            const json = await res.json();
            alert(json.message);
            closeModal();
            fetchBotStatus();
        } catch (e) {
            alert("Kill Switch trigger failed: " + e);
        }
    }
}

async function fetchStrategyConfig() {
    try {
        const res = await fetch("/api/strategy/config");
        const json = await res.json();
        if (json.config) {
            const c = json.config;
            document.getElementById("cfg-ema-fast").value = c.ema_fast_cross;
            document.getElementById("cfg-ema-slow").value = c.ema_slow_cross;
            document.getElementById("cfg-ema-trend").value = c.ema_trend_filter;
            document.getElementById("cfg-rsi-len").value = c.rsi_length;
            document.getElementById("cfg-sl-pct").value = c.fixed_stop_loss_pct;
            document.getElementById("cfg-rr-ratio").value = c.fixed_risk_reward_ratio;
            document.getElementById("cfg-risk-pct").value = c.risk_pct_per_trade;
            document.getElementById("cfg-daily-loss").value = c.daily_loss_limit_pct;
            document.getElementById("cfg-allow-shorts").checked = c.allow_shorts;
            document.getElementById("cfg-use-rsi").checked = c.use_rsi_filter;
            document.getElementById("cfg-use-ema9").checked = c.use_ema9_filter;
        }
    } catch (e) {
        console.error("Strategy config fetch error:", e);
    }
}

async function saveStrategyConfig(e) {
    e.preventDefault();
    const body = {
        ema_fast_cross: parseInt(document.getElementById("cfg-ema-fast").value),
        ema_slow_cross: parseInt(document.getElementById("cfg-ema-slow").value),
        ema_trend_filter: parseInt(document.getElementById("cfg-ema-trend").value),
        rsi_length: parseInt(document.getElementById("cfg-rsi-len").value),
        fixed_stop_loss_pct: parseFloat(document.getElementById("cfg-sl-pct").value),
        fixed_risk_reward_ratio: parseFloat(document.getElementById("cfg-rr-ratio").value),
        risk_pct_per_trade: parseFloat(document.getElementById("cfg-risk-pct").value),
        daily_loss_limit_pct: parseFloat(document.getElementById("cfg-daily-loss").value),
        allow_shorts: document.getElementById("cfg-allow-shorts").checked,
        use_rsi_filter: document.getElementById("cfg-use-rsi").checked,
        use_ema9_filter: document.getElementById("cfg-use-ema9").checked
    };

    try {
        const res = await fetch("/api/strategy/config", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(body)
        });
        const json = await res.json();
        alert(json.message);
    } catch (err) {
        alert("Failed to save strategy config: " + err);
    }
}

// --------------------------------------------------------------------------
// SECTION 3: RISK CALCULATOR
// --------------------------------------------------------------------------
async function calculatePositionSize() {
    const body = {
        account_balance: parseFloat(document.getElementById("calc-balance").value),
        risk_pct: parseFloat(document.getElementById("calc-risk-pct").value) / 100.0,
        entry_price: parseFloat(document.getElementById("calc-entry").value),
        stop_loss_price: parseFloat(document.getElementById("calc-sl").value)
    };

    try {
        const res = await fetch("/api/risk/calculate", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(body)
        });
        const json = await res.json();
        if (json.status === "success") {
            const calc = json.calculation;
            document.getElementById("res-risk-amt").textContent = `$${calc.risk_amount_usdt.toFixed(2)}`;
            document.getElementById("res-dist-pct").textContent = `${calc.distance_pct.toFixed(2)}%`;
            document.getElementById("res-units").textContent = `${calc.position_units_btc.toFixed(4)} BTC`;
            document.getElementById("res-val").textContent = `$${calc.position_value_usdt.toFixed(2)}`;
            document.getElementById("res-tp").textContent = `$${calc.suggested_take_profit.toFixed(2)}`;
        } else {
            alert(json.message);
        }
    } catch (e) {
        alert("Position calculation error: " + e);
    }
}

// --------------------------------------------------------------------------
// SECTION 4: PERFORMANCE ANALYTICS & TRADES
// --------------------------------------------------------------------------
async function fetchAnalytics() {
    try {
        const res = await fetch("/api/analytics");
        const json = await res.json();
        if (json.status === "success") {
            const m = json.metrics;
            document.getElementById("pnl-alltime").textContent = `$${m.pnl_all_time.toFixed(2)}`;
            document.getElementById("pnl-today").textContent = `$${m.pnl_today.toFixed(2)}`;
            document.getElementById("analytics-winrate").textContent = `${m.win_rate_pct.toFixed(1)}%`;
            document.getElementById("analytics-pf").textContent = m.profit_factor.toFixed(2);
            document.getElementById("analytics-maxdd").textContent = `${m.max_drawdown_pct.toFixed(2)}%`;
            document.getElementById("analytics-sharpe").textContent = m.sharpe_ratio.toFixed(2);

            renderEquityChart(json.equity_curve);
        }
    } catch (e) {
        console.error("Analytics fetch error:", e);
    }
}

function renderEquityChart(curveData) {
    const canvas = document.getElementById("equity-chart-canvas");
    if (!canvas || !curveData || curveData.length === 0) return;

    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--bg-card') || "#141822";
    ctx.fillRect(0, 0, width, height);

    const equities = curveData.map(d => d.equity);
    const minEq = Math.min(...equities) * 0.98;
    const maxEq = Math.max(...equities) * 1.02;

    ctx.strokeStyle = "#00c076";
    ctx.lineWidth = 2;
    ctx.beginPath();

    curveData.forEach((d, idx) => {
        const x = (idx / (curveData.length - 1 || 1)) * (width - 40) + 20;
        const y = height - ((d.equity - minEq) / (maxEq - minEq || 1)) * (height - 30) - 15;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    ctx.stroke();
}

async function fetchTrades() {
    try {
        const res = await fetch("/api/trades");
        const json = await res.json();
        if (json.trades) {
            renderTradesTable(json.trades);
        }
    } catch (e) {
        console.error("Trades fetch error:", e);
    }
}

function renderTradesTable(trades) {
    const body = document.getElementById("trades-table-body");
    if (!trades || trades.length === 0) {
        body.innerHTML = `<tr><td colspan="11" class="text-center text-muted">No trade history recorded yet.</td></tr>`;
        return;
    }

    body.innerHTML = trades.map(t => `
        <tr>
            <td>${t.id}</td>
            <td>${t.timestamp.replace('T', ' ').slice(0, 19)}</td>
            <td>${t.symbol}</td>
            <td><b class="${t.direction === 'LONG' ? 'text-success' : 'text-danger'}">${t.direction}</b></td>
            <td>$${t.entry_price.toFixed(2)}</td>
            <td>$${t.stop_loss.toFixed(2)}</td>
            <td>$${t.take_profit.toFixed(2)}</td>
            <td>${t.position_size.toFixed(4)}</td>
            <td><span class="status-badge">${t.status}</span></td>
            <td>${t.exit_price ? '$' + t.exit_price.toFixed(2) : '-'}</td>
            <td><b class="${(t.result_pnl || 0) >= 0 ? 'text-success' : 'text-danger'}">$${(t.result_pnl || 0).toFixed(2)}</b></td>
        </tr>
    `).join('');
}

function exportTradesCSV() {
    window.location.href = "/api/trades/export";
}

// --------------------------------------------------------------------------
// SECTION 5: BACKTESTING
// --------------------------------------------------------------------------
async function runBacktest(e) {
    e.preventDefault();
    const btn = document.getElementById("btn-run-bt");
    btn.disabled = true;
    btn.textContent = "⏳ Running Backtest...";

    const body = {
        start_date: document.getElementById("bt-start-date").value,
        end_date: document.getElementById("bt-end-date").value,
        initial_cash: parseFloat(document.getElementById("bt-capital").value),
        strategy_name: document.getElementById("bt-strategy").value
    };

    try {
        const res = await fetch("/api/backtest/run", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(body)
        });
        const json = await res.json();
        if (json.status === "success") {
            const bt = json.backtest;
            document.getElementById("bt-profit").textContent = `$${bt.total_net_profit.toFixed(2)}`;
            document.getElementById("bt-return").textContent = `${bt.return_pct.toFixed(2)}%`;
            document.getElementById("bt-trades").textContent = bt.total_trades;
            document.getElementById("bt-winrate").textContent = `${bt.win_rate_pct.toFixed(2)}%`;
            document.getElementById("bt-maxdd").textContent = `${bt.max_drawdown_pct.toFixed(2)}%`;
            document.getElementById("bt-sharpe").textContent = bt.sharpe_ratio.toFixed(2);
            alert("Backtest simulation completed!");
        } else {
            alert(json.message);
        }
    } catch (err) {
        alert("Backtest error: " + err);
    } finally {
        btn.disabled = false;
        btn.textContent = "🧪 Run Backtest Simulation";
    }
}

// --------------------------------------------------------------------------
// SECTION 6: ALERTS & NOTIFICATIONS
// --------------------------------------------------------------------------
async function fetchNotifications() {
    try {
        const res = await fetch("/api/alerts");
        const json = await res.json();
        if (json.notifications) {
            const container = document.getElementById("notification-feed");
            if (json.notifications.length === 0) {
                container.innerHTML = `<div class="text-center text-muted">No notifications.</div>`;
                return;
            }
            container.innerHTML = json.notifications.map(n => `
                <div class="feed-item level-${n.level.toLowerCase()}">
                    <span class="feed-time">${n.timestamp.slice(11, 19)}</span>
                    <span class="feed-cat">[${n.category}]</span>
                    <span>${n.message}</span>
                </div>
            `).join('');
        }
    } catch (e) {
        console.error("Notification fetch error:", e);
    }
}

async function sendTestAlert(channel) {
    try {
        const res = await fetch("/api/alerts/test", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({channel})
        });
        const json = await res.json();
        alert(json.message);
    } catch (e) {
        alert("Failed to send test alert: " + e);
    }
}

// --------------------------------------------------------------------------
// SECTION 7: ACCOUNT & SECURITY
// --------------------------------------------------------------------------
async function saveApiKeys(e) {
    e.preventDefault();
    const apiKey = document.getElementById("sec-api-key").value;
    const secretKey = document.getElementById("sec-secret-key").value;

    try {
        const res = await fetch("/api/security/apikeys", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({api_key: apiKey, secret_key: secretKey})
        });
        const json = await res.json();
        alert(json.message);
    } catch (e) {
        alert("Save API keys error: " + e);
    }
}

async function fetchAuditLogs() {
    try {
        const res = await fetch("/api/security/audit");
        const json = await res.json();
        if (json.audit_logs) {
            const container = document.getElementById("audit-log-container");
            container.innerHTML = json.audit_logs.map(a => `
                <div class="audit-row">
                    <span>${a.timestamp.slice(0, 19)}</span>
                    <b>${a.action}</b>
                    <span>${a.user}</span>
                </div>
            `).join('');
        }
    } catch (e) {
        console.error("Audit log error:", e);
    }
}

// --------------------------------------------------------------------------
// SECTION 8: LOGS & DEBUGGING
// --------------------------------------------------------------------------
async function fetchLogs() {
    const level = document.getElementById("log-level-filter").value;
    const search = document.getElementById("log-search-input").value;

    try {
        const res = await fetch(`/api/logs?level=${level}&search=${search}`);
        const json = await res.json();
        if (json.logs) {
            const terminal = document.getElementById("log-terminal");
            terminal.innerHTML = json.logs.map(line => `<div>${escapeHtml(line)}</div>`).join('');
        }

        // Active Error Banner
        if (json.system_errors && json.system_errors.length > 0) {
            const banner = document.getElementById("error-banner");
            const body = document.getElementById("error-banner-body");
            banner.style.display = "block";
            body.innerHTML = json.system_errors.map(err => `<div>[${err.timestamp}] ${err.error_message}</div>`).join('');
        }
    } catch (e) {
        console.error("Logs fetch error:", e);
    }
}

function toggleErrorDetails() {
    const body = document.getElementById("error-banner-body");
    body.style.display = body.style.display === "none" ? "block" : "none";
}

async function copyDiagnosticReport() {
    try {
        const res = await fetch("/api/logs/diagnostic_report");
        const json = await res.json();
        if (json.report) {
            navigator.clipboard.writeText(json.report);
            alert("Diagnostic report copied to clipboard!");
        }
    } catch (e) {
        alert("Failed to generate diagnostic report: " + e);
    }
}

function toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme");
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    document.getElementById("theme-toggle").textContent = next === "dark" ? "🌙" : "☀️";
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
